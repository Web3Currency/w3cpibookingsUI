import { useState, useEffect } from 'react';
import { Service, Booking, PiUser } from './types';
import { useBusiness } from './hooks/useBusiness';
import { useServices } from './hooks/useServices';
import { useBookings } from './hooks/useBookings';
import { useAuth } from './hooks/useAuth';
import { piAuthService } from './services/piAuthService';
import { bookingService } from './services/bookingService';

import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { ServiceBrowser } from './components/ServiceBrowser';
import { ServiceDetail } from './components/ServiceDetail';
import { SelectDetailsStep } from './components/SelectDetailsStep';
import { SelectScheduleStep } from './components/SelectScheduleStep';
import { BookingSummaryStep } from './components/BookingSummaryStep';
import { PiPaymentModal } from './components/PiPaymentModal';
import { BookingConfirmationStep } from './components/BookingConfirmationStep';
import { BookingStatusView } from './components/BookingStatusView';
import { BusinessAboutView } from './components/BusinessAboutView';
import { ConsoleAuthModal } from './features/auth/ConsoleAuthModal';
import { BusinessConsoleView } from './features/business/BusinessConsoleView';

type FlowStep =
  | 'browse'
  | 'about'
  | 'detail'
  | 'select_details'
  | 'select_schedule'
  | 'review_summary'
  | 'payment'
  | 'confirmation'
  | 'status';

export default function App() {
  const { business, loading: loadingBusiness, refreshBusiness } = useBusiness();
  const { services, refreshServices } = useServices();
  const { bookings, refreshBookings } = useBookings();
  const { isAuthenticated } = useAuth();

  const [isConsoleOpen, setIsConsoleOpen] = useState<boolean>(false);
  const [isConsoleAuthModalOpen, setIsConsoleAuthModalOpen] = useState<boolean>(false);
  const [piUser, setPiUser] = useState<PiUser | null>(null);

  const [activeTab, setActiveTab] = useState<'browse' | 'bookings'>('browse');
  const [currentFlow, setCurrentFlow] = useState<FlowStep>('browse');

  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  const [clientDetails, setClientDetails] = useState<{
    clientName: string;
    clientPiUsername: string;
    clientPhone: string;
    notes: string;
    attachments?: { id: string; name: string; size: string; type: string; dataUrl?: string }[];
  }>({
    clientName: 'Pioneer User',
    clientPiUsername: '@pioneer_user_pi',
    clientPhone: '+2348149625496',
    notes: '',
    attachments: [],
  });

  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  const handleRefreshAll = async () => {
    await Promise.all([refreshBusiness(), refreshServices(), refreshBookings()]);
  };

  useEffect(() => {
    piAuthService.authenticateUser().then((user) => {
      setPiUser(user);
      if (user) {
        setClientDetails((prev) => ({
          ...prev,
          clientName: user.username ? `Pioneer ${user.username}` : prev.clientName,
          clientPiUsername: user.username
            ? (user.username.startsWith('@') ? user.username : `@${user.username}`)
            : prev.clientPiUsername,
        }));
      }
    });
  }, []);

  const handleSelectTab = (tab: 'browse' | 'bookings') => {
    setActiveTab(tab);
    if (tab === 'browse') {
      setCurrentFlow('browse');
    } else {
      setCurrentFlow('status');
    }
  };

  const handleSelectService = (service: Service) => {
    setActiveTab('browse');
    setSelectedService(service);
    setCurrentFlow('detail');
  };

  const handleStartBooking = () => {
    setActiveTab('browse');
    setCurrentFlow('select_details');
  };

  const handleConfirmDetails = (details: {
    clientName: string;
    clientPiUsername: string;
    clientPhone: string;
    notes: string;
    attachments?: { id: string; name: string; size: string; type: string; dataUrl?: string }[];
  }) => {
    setActiveTab('browse');
    setClientDetails(details);
    setCurrentFlow('select_schedule');
  };

  const handleConfirmSchedule = (date: string, timeSlot: string) => {
    setActiveTab('browse');
    setSelectedDate(date);
    setSelectedTimeSlot(timeSlot);
    setCurrentFlow('review_summary');
  };

  const handleProceedToPayment = () => {
    setActiveTab('browse');
    setCurrentFlow('payment');
  };

  const handlePaymentSuccess = async (newBooking: Booking) => {
    setActiveTab('browse');
    const created = await bookingService.saveBookingAsync(newBooking);
    setConfirmedBooking(created);
    await handleRefreshAll();
    setCurrentFlow('confirmation');
  };

  const handleGoToMyBookings = () => {
    setActiveTab('bookings');
    setCurrentFlow('status');
  };

  const handleCancelBooking = async (bookingId: string) => {
    await bookingService.updateBookingStatusAsync(bookingId, 'Cancelled');
    await refreshBookings();
  };

  const handleRescheduleBooking = (booking: Booking) => {
    setActiveTab('browse');
    if (business) {
      const srv = services.find((s) => s.id === booking.serviceId) || services[0];
      setSelectedService(srv);
      setCurrentFlow('select_details');
    }
  };

  const handleOpenConsole = () => {
    if (isAuthenticated) {
      setIsConsoleOpen(true);
    } else {
      setIsConsoleAuthModalOpen(true);
    }
  };

  const businessWithServices = {
    ...business,
    services,
  };

  if (loadingBusiness && !business) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4 text-center space-y-3">
        <div className="w-8 h-8 rounded-full border-2 border-amber-500 border-t-transparent animate-spin mx-auto" />
        <span className="text-xs font-bold text-zinc-400">Loading Pi Business OS...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-900 text-zinc-100 font-sans selection:bg-amber-500 selection:text-zinc-950 transition-colors">
      <Navbar currentBusiness={businessWithServices} piUser={piUser} />

      {isConsoleAuthModalOpen && (
        <ConsoleAuthModal
          onSuccess={() => {
            setIsConsoleAuthModalOpen(false);
            setIsConsoleOpen(true);
          }}
          onClose={() => setIsConsoleAuthModalOpen(false)}
        />
      )}

      <main className="max-w-md mx-auto px-4 pt-4 pb-20">
        {isConsoleOpen ? (
          <BusinessConsoleView
            onExitConsole={() => {
              setIsConsoleOpen(false);
              handleRefreshAll();
            }}
            onDataChanged={handleRefreshAll}
          />
        ) : activeTab === 'browse' ? (
          currentFlow === 'browse' ? (
            <ServiceBrowser
              business={businessWithServices}
              onSelectService={handleSelectService}
              onOpenAbout={() => setCurrentFlow('about')}
            />
          ) : currentFlow === 'about' ? (
            <BusinessAboutView
              business={businessWithServices}
              onBack={() => setCurrentFlow('browse')}
              onOpenAdmin={handleOpenConsole}
            />
          ) : currentFlow === 'detail' && selectedService ? (
            <ServiceDetail
              service={selectedService}
              business={businessWithServices}
              onBack={() => setCurrentFlow('browse')}
              onProceedToBooking={handleStartBooking}
            />
          ) : currentFlow === 'select_details' && selectedService ? (
            <SelectDetailsStep
              service={selectedService}
              initialDetails={clientDetails}
              onBack={() => setCurrentFlow('detail')}
              onProceedToSchedule={handleConfirmDetails}
            />
          ) : currentFlow === 'select_schedule' && selectedService ? (
            <SelectScheduleStep
              service={selectedService}
              initialDate={selectedDate}
              initialTimeSlot={selectedTimeSlot}
              onBack={() => setCurrentFlow('select_details')}
              onConfirmSchedule={handleConfirmSchedule}
            />
          ) : currentFlow === 'review_summary' && selectedService ? (
            <BookingSummaryStep
              service={selectedService}
              business={businessWithServices}
              selectedDate={selectedDate}
              selectedTimeSlot={selectedTimeSlot}
              clientDetails={clientDetails}
              piUser={piUser}
              onBack={() => setCurrentFlow('select_schedule')}
              onProceedToPayment={handleProceedToPayment}
            />
          ) : currentFlow === 'payment' && selectedService ? (
            <PiPaymentModal
              service={selectedService}
              business={businessWithServices}
              date={selectedDate}
              timeSlot={selectedTimeSlot}
              clientDetails={clientDetails}
              piUser={piUser}
              onBack={() => setCurrentFlow('review_summary')}
              onPaymentComplete={handlePaymentSuccess}
            />
          ) : currentFlow === 'confirmation' && confirmedBooking ? (
            <BookingConfirmationStep
              booking={confirmedBooking}
              onGoToBookings={handleGoToMyBookings}
            />
          ) : (
            <ServiceBrowser
              business={businessWithServices}
              onSelectService={handleSelectService}
              onOpenAbout={() => setCurrentFlow('about')}
            />
          )
        ) : (
          <BookingStatusView
            bookings={bookings}
            onBrowseServices={() => {
              setActiveTab('browse');
              setCurrentFlow('browse');
            }}
            onCancelBooking={handleCancelBooking}
            onRescheduleBooking={handleRescheduleBooking}
          />
        )}
      </main>

      {!isConsoleOpen && (activeTab === 'bookings' || (activeTab === 'browse' && currentFlow === 'browse')) && (
        <BottomNav
          activeTab={activeTab}
          onSelectTab={handleSelectTab}
          bookingsCount={bookings.filter((b) => b.status === 'Confirmed' || b.status === 'In Progress').length}
        />
      )}
    </div>
  );
}
