import React, { useState } from 'react';
import { Booking } from '../types';
import { CheckCircle2, Calendar, Clock, Copy, QrCode, Download, ArrowRight, ShieldCheck, Check, MessageSquare } from 'lucide-react';

interface BookingConfirmationStepProps {
  booking: Booking;
  onGoToBookings: () => void;
}

export const BookingConfirmationStep: React.FC<BookingConfirmationStepProps> = ({
  booking,
  onGoToBookings,
}) => {
  const [copiedTxHash, setCopiedTxHash] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);

  const telegramLink = `https://t.me/Web3CurrencyNG?text=Hi!%20I%20just%20booked%20${encodeURIComponent(booking.serviceName)}%20(Booking%20%23${booking.id})`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTxHash(true);
    setTimeout(() => setCopiedTxHash(false), 2000);
  };

  const generateICSFile = () => {
    const icsData = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//W3C Digital Network Appointment Pass//EN
BEGIN:VEVENT
SUMMARY:${booking.serviceName} - ${booking.businessName}
DESCRIPTION:Appointment booked on W3C Digital Network. Reference ID: ${booking.id}
DTSTART:${booking.date.replace(/-/g, '')}T100000Z
DTEND:${booking.date.replace(/-/g, '')}T110000Z
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `appointment-${booking.id}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5 pb-28 animate-in fade-in slide-in-from-bottom-4 duration-300">
      {/* Celebration Banner */}
      <div className="text-center pt-2 space-y-2">
        <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center ring-4 ring-emerald-500/10 animate-bounce">
          <CheckCircle2 className="w-9 h-9 stroke-[2.5]" />
        </div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-extrabold uppercase tracking-wider border border-emerald-500/30">
          <span>✓ Payment Received ({booking.pricePi.toFixed(2)} π)</span>
        </div>
        <h1 className="text-2xl font-black text-white tracking-tight">
          Booking Confirmed!
        </h1>
        <p className="text-xs text-zinc-400 max-w-xs mx-auto font-mono">
          Ref ID: <span className="text-amber-400 font-bold">#{booking.id}</span>
        </p>
      </div>

      {/* Hero Telegram Handoff Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-950/80 via-zinc-900 to-zinc-900 shadow-2xl space-y-3.5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center gap-2 text-blue-400 text-xs font-black uppercase tracking-wider">
          <MessageSquare className="w-4 h-4 text-blue-400" />
          <span>🚀 NEXT STEP: CONNECT ON TELEGRAM</span>
        </div>

        <p className="text-xs text-zinc-200 leading-relaxed">
          To start your project and share requirements, assets, and design feedback, jump straight into our project workspace on Telegram!
        </p>

        {/* Primary High-Visibility Telegram CTA Button */}
        <a
          href={telegramLink}
          target="_blank"
          rel="noopener noreferrer"
          id="btn-telegram-handoff"
          className="w-full py-3.5 px-4 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-black text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <MessageSquare className="w-5 h-5 fill-current" />
          <span>Continue Chat on Telegram →</span>
        </a>

        {/* Clear Expectations Banner */}
        <div className="p-3 rounded-xl bg-zinc-950/60 text-[11px] text-zinc-400 flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <span>
            <strong>Client Note:</strong> For real-time project updates, direct asset file sharing, and instant discussions, all communication is hosted on Telegram.
          </span>
        </div>
      </div>

      {/* Official Digital Pass Card */}
      <div className="rounded-2xl bg-zinc-800 overflow-hidden shadow-xl space-y-0">
        {/* Header Ticket Band */}
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-zinc-950 p-4 font-black">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wider bg-zinc-950 text-amber-300 px-2.5 py-0.5 rounded-full font-extrabold">
              OFFICIAL APPOINTMENT PASS
            </span>
            <span className="text-xs font-black uppercase tracking-wider bg-zinc-950/20 px-2.5 py-0.5 rounded-full">
              CONFIRMED
            </span>
          </div>

          <div className="mt-3">
            <h2 className="text-lg font-black leading-snug">{booking.serviceName}</h2>
            <p className="text-xs text-zinc-900 font-semibold mt-0.5">{booking.businessName}</p>
          </div>
        </div>

        {/* Date & Time Grid */}
        <div className="p-4 bg-zinc-900/80 border-b border-dashed border-zinc-700 grid grid-cols-2 gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-amber-400" />
            <div>
              <span className="text-[10px] text-zinc-400 block font-medium">DATE</span>
              <span className="font-bold text-white">{booking.date}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <div>
              <span className="text-[10px] text-zinc-400 block font-medium">TIME SLOT</span>
              <span className="font-bold text-white">{booking.timeSlot}</span>
            </div>
          </div>
        </div>

        {/* Pass Details */}
        <div className="p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400">Booking Reference</span>
            <span className="font-mono font-bold text-white">#{booking.id}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-zinc-400">Pioneer Client</span>
            <span className="font-bold text-white">
              {booking.clientName} ({booking.clientPiUsername})
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-zinc-400">Pi Payment Amount</span>
            <span className="font-black text-amber-400 text-sm">{booking.pricePi.toFixed(2)} π</span>
          </div>

          {/* Blockchain Transaction Hash */}
          {booking.piTxHash && (
            <div className="p-2.5 rounded-xl bg-zinc-900 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <span className="text-[10px] text-zinc-400 font-semibold block uppercase">PI BLOCKCHAIN TX HASH</span>
                <span className="font-mono text-[11px] text-zinc-200 truncate block">
                  {booking.piTxHash}
                </span>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard(booking.piTxHash!)}
                id="btn-copy-confirmation-hash"
                className="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:text-amber-400 transition shrink-0"
                title="Copy Transaction Hash"
              >
                {copiedTxHash ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          )}

          {/* Ticket Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowQRModal(true)}
              id="btn-show-qr-pass"
              className="py-2.5 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <QrCode className="w-4 h-4" />
              <span>Show QR Ticket</span>
            </button>

            <button
              type="button"
              onClick={generateICSFile}
              id="btn-download-ics-calendar"
              className="py-2.5 px-3 rounded-xl bg-zinc-700 hover:bg-zinc-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <Download className="w-4 h-4" />
              <span>Add to Calendar</span>
            </button>
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQRModal && (
        <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xs rounded-2xl bg-zinc-900 p-6 space-y-4 text-center shadow-2xl">
            <h3 className="text-base font-bold text-white">
              Appointment QR Ticket
            </h3>

            <div className="p-4 bg-white rounded-xl inline-block mx-auto">
              <img
                src={booking.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${booking.id}`}
                alt="Booking Check-In QR"
                className="w-40 h-40"
              />
            </div>

            <p className="text-xs text-zinc-400">
              Present this QR code to <strong className="text-white">{booking.businessName}</strong> upon session arrival or check-in.
            </p>

            <button
              type="button"
              onClick={() => setShowQRModal(false)}
              id="btn-close-qr-modal"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs"
            >
              Close Ticket
            </button>
          </div>
        </div>
      )}

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-900/95 backdrop-blur-md border-t border-zinc-800 z-30">
        <div className="max-w-md mx-auto">
          <button
            type="button"
            onClick={onGoToBookings}
            id="btn-view-my-bookings"
            className="w-full py-3.5 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-sm active:scale-[0.98] transition flex items-center justify-center gap-2 min-h-[48px]"
          >
            <span>View in My Bookings</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
