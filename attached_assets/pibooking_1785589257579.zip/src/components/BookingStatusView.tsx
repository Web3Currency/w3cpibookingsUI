import React, { useState } from 'react';
import { Booking } from '../types';
import {
  CalendarCheck,
  CheckCircle2,
  CheckCheck,
  Clock,
  QrCode,
  Copy,
  Download,
  XCircle,
  MessageSquare,
  ShieldCheck,
  Star,
  Send,
  Check,
  FileText,
  Paperclip
} from 'lucide-react';

interface BookingStatusViewProps {
  bookings: Booking[];
  onBrowseServices: () => void;
  onCancelBooking: (bookingId: string) => void;
  onRescheduleBooking: (booking: Booking) => void;
  onAddReview?: (bookingId: string, rating: number, comment: string) => void;
}

export const BookingStatusView: React.FC<BookingStatusViewProps> = ({
  bookings,
  onBrowseServices,
  onCancelBooking,
  onRescheduleBooking,
  onAddReview,
}) => {
  const [filter, setFilter] = useState<'all' | 'confirmed' | 'completed' | 'cancelled'>('all');
  const [selectedBookingId, setSelectedBookingId] = useState<string>(bookings[0]?.id || '');
  const [copiedTxHash, setCopiedTxHash] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);

  // Review Form state
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');
  const [reviewSubmitted, setReviewSubmitted] = useState<boolean>(false);

  const filteredBookings = bookings.filter((b) => {
    if (filter === 'all') return true;
    return b.status === filter;
  });

  const activeBooking = bookings.find((b) => b.id === selectedBookingId) || filteredBookings[0] || bookings[0];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTxHash(true);
    setTimeout(() => setCopiedTxHash(false), 2000);
  };

  const generateICSFile = (b: Booking) => {
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//W3C Digital Network Appointment Pass//EN
BEGIN:VEVENT
SUMMARY:${b.serviceName} - ${b.businessName}
DESCRIPTION:Appointment for ${b.serviceName} paid with ${b.pricePi} Pi. Booking ID: ${b.id}
DTSTART:${b.date.replace(/-/g, '')}T100000Z
DTEND:${b.date.replace(/-/g, '')}T110000Z
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `booking-${b.id}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeBooking && onAddReview) {
      onAddReview(activeBooking.id, reviewRating, reviewComment);
    }
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 3000);
  };

  if (bookings.length === 0) {
    return (
      <div className="text-center py-16 px-4 space-y-4">
        <div className="w-16 h-16 mx-auto rounded-full bg-zinc-800 text-zinc-400 flex items-center justify-center">
          <CalendarCheck className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">No Bookings Yet</h2>
          <p className="text-xs text-zinc-400 mt-1 max-w-xs mx-auto">
            You have not booked any appointments with W3C Digital Network yet.
          </p>
        </div>
        <button
          type="button"
          onClick={onBrowseServices}
          id="btn-empty-browse-services"
          className="py-3 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition"
        >
          Browse Services
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-24 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black text-white">My Bookings</h1>
          <p className="text-xs text-zinc-400">
            {bookings.length} appointment record{bookings.length > 1 ? 's' : ''} on Pi Blockchain
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {(['all', 'confirmed', 'completed', 'cancelled'] as const).map((st) => (
          <button
            key={st}
            type="button"
            onClick={() => setFilter(st)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold capitalize transition shrink-0 ${
              filter === st
                ? 'bg-amber-500 text-zinc-950'
                : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
            }`}
          >
            {st === 'all' ? 'All Bookings' : st}
          </button>
        ))}
      </div>

      {/* Booking List Selector Cards */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {filteredBookings.map((b) => {
          const isSelected = activeBooking?.id === b.id;
          return (
            <button
              key={b.id}
              type="button"
              onClick={() => setSelectedBookingId(b.id)}
              className={`p-3 rounded-2xl text-xs font-semibold shrink-0 transition min-w-[160px] text-left ${
                isSelected
                  ? 'bg-amber-500 text-zinc-950 font-black shadow-md'
                  : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
              }`}
            >
              <div className="font-extrabold truncate">{b.serviceName}</div>
              <div className={`text-[10px] mt-0.5 ${isSelected ? 'text-zinc-900 font-bold' : 'text-zinc-400'}`}>
                {b.date} • {b.timeSlot}
              </div>
              <div className="mt-1 flex items-center justify-between">
                <span className={`text-[10px] font-mono font-extrabold ${isSelected ? 'text-zinc-950' : 'text-amber-400'}`}>
                  #{b.id}
                </span>
                <span className={`text-[9px] uppercase px-1.5 py-0.2 rounded font-extrabold ${
                  b.status === 'confirmed' ? (isSelected ? 'bg-zinc-950 text-emerald-300' : 'bg-emerald-950 text-emerald-300') : 'bg-zinc-900 text-zinc-400'
                }`}>
                  {b.status}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {activeBooking && (
        <div className="space-y-4">
          {/* Main Selected Booking Ticket Pass Card */}
          <div className="rounded-2xl bg-zinc-800 overflow-hidden space-y-0 shadow-xl">
            {/* Top Header Ticket Band */}
            <div className="bg-zinc-800 p-4 border-b border-zinc-700/60">
              <div>
                <h2 className="text-lg font-black tracking-tight text-white">{activeBooking.serviceName}</h2>
                <p className="text-xs text-zinc-300 mt-0.5">{activeBooking.businessName}</p>
              </div>
            </div>

            {/* Persistent Telegram Action Hero Banner (For Active Bookings) */}
            {activeBooking.status === 'confirmed' && (
              <div className="p-4 bg-gradient-to-br from-blue-950/90 via-zinc-900 to-zinc-900 border-b border-blue-500/40 space-y-3 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-28 h-28 bg-blue-500/10 rounded-full blur-xl pointer-events-none" />

                <div className="flex items-center gap-2 text-blue-400 text-xs font-black uppercase tracking-wider">
                  <span>CONNECT ON TELEGRAM</span>
                </div>

                <p className="text-xs text-zinc-200 leading-relaxed font-medium">
                  To start your project and share requirements, assets, and design feedback, jump into our Telegram!
                </p>

                <a
                  href={`https://t.me/Web3CurrencyNG?text=Hi!%20I%20am%20following%20up%20on%20Booking%20%23${activeBooking.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  id={`btn-telegram-my-bookings-${activeBooking.id}`}
                  className="w-full py-3 px-4 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-[0.98] shadow-md shadow-blue-500/20"
                >
                  <span>Continue Chat on Telegram →</span>
                </a>
              </div>
            )}

            {/* Date & Time Grid */}
            <div className="p-4 bg-zinc-900/60 border-b border-dashed border-zinc-700 grid grid-cols-2 gap-3 text-xs">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="text-[10px] text-zinc-400 block font-medium">DATE</span>
                  <span className="font-bold text-white">{activeBooking.date}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="text-[10px] text-zinc-400 block font-medium">TIME SLOT</span>
                  <span className="font-bold text-white">{activeBooking.timeSlot}</span>
                </div>
              </div>
            </div>

            {/* Pass Details */}
            <div className="p-4 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Booking Reference</span>
                <span className="font-mono font-bold text-white">#{activeBooking.id}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Pioneer Client</span>
                <span className="font-bold text-white">
                  {activeBooking.clientName} ({activeBooking.clientPiUsername})
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Pi Payment Amount</span>
                <span className="font-black text-amber-400 text-sm">{activeBooking.pricePi} π</span>
              </div>

              {activeBooking.notes && (
                <div className="pt-2 border-t border-zinc-700/60">
                  <span className="text-zinc-400 block text-[10px] font-bold uppercase">Appointment Notes</span>
                  <p className="text-xs text-zinc-300 mt-0.5 italic">"{activeBooking.notes}"</p>
                </div>
              )}

              {activeBooking.attachments && activeBooking.attachments.length > 0 && (
                <div className="pt-2 border-t border-zinc-700/60">
                  <span className="text-zinc-400 block text-[10px] font-bold uppercase mb-1">
                    Attached Files ({activeBooking.attachments.length})
                  </span>
                  <div className="space-y-1">
                    {activeBooking.attachments.map((att) => (
                      <div key={att.id} className="p-2 rounded-lg bg-zinc-900 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <Paperclip className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span className="font-medium text-zinc-200 truncate">{att.name}</span>
                        </div>
                        <span className="text-[10px] text-zinc-500 shrink-0">{att.size}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Escrow & Guarantee Badging */}
              <div className="p-2.5 rounded-xl bg-emerald-950/40 flex items-center gap-2 text-[11px] text-emerald-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Protected by Pi Network Escrow & Refund Guarantee</span>
              </div>

              {/* Pi Transaction Hash */}
              {activeBooking.piTxHash && (
                <div className="p-2.5 rounded-xl bg-zinc-900 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="text-[10px] text-zinc-400 font-semibold block uppercase">PI BLOCKCHAIN TX HASH</span>
                    <span className="font-mono text-[11px] text-zinc-200 truncate block">
                      {activeBooking.piTxHash}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(activeBooking.piTxHash!)}
                    id="btn-copy-tx-hash-my-bookings"
                    className="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:text-amber-400 transition shrink-0"
                    title="Copy Transaction Hash"
                  >
                    {copiedTxHash ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              )}

              {/* Action Buttons: QR Ticket + Add to Calendar */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowQRModal(true)}
                  id="btn-show-qr-my-bookings"
                  className="py-2.5 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Show QR Ticket</span>
                </button>

                <button
                  type="button"
                  onClick={() => generateICSFile(activeBooking)}
                  id="btn-download-ics-my-bookings"
                  className="py-2.5 px-3 rounded-xl bg-zinc-700 hover:bg-zinc-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Download className="w-4 h-4" />
                  <span>Add Calendar</span>
                </button>
              </div>

              {/* Cancellation Option */}
              {activeBooking.status === 'confirmed' && (
                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => onCancelBooking(activeBooking.id)}
                    className="text-xs text-red-400 hover:text-red-300 underline font-semibold"
                  >
                    Request Appointment Cancellation / Refund
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Rating & Review Submission Module (For Completed or Past Bookings) */}
          {(activeBooking.status === 'completed' || activeBooking.status === 'confirmed') && (
            <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span>Leave Service Star Review</span>
                </h3>
                <span className="text-[10px] text-zinc-500">Verified Pi Client Review</span>
              </div>

              {activeBooking.rating || reviewSubmitted ? (
                <div className="p-3 rounded-xl bg-emerald-950/40 text-center space-y-1">
                  <div className="flex justify-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= (activeBooking.rating || reviewRating)
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-zinc-600'
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-xs font-extrabold text-emerald-300">
                    Thank you! Review submitted successfully.
                  </p>
                  {activeBooking.reviewComment && (
                    <p className="text-xs text-zinc-300 italic">"{activeBooking.reviewComment}"</p>
                  )}
                </div>
              ) : (
                <form onSubmit={handleReviewSubmit} className="space-y-3">
                  <p className="text-xs text-zinc-400">
                    How was your experience with <strong className="text-zinc-200">{activeBooking.serviceName}</strong>?
                  </p>

                  {/* Star Rating Buttons */}
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className={`p-1.5 rounded-lg transition ${
                          star <= reviewRating ? 'text-amber-400 bg-amber-500/10' : 'text-zinc-600 hover:text-zinc-400'
                        }`}
                      >
                        <Star className={`w-6 h-6 ${star <= reviewRating ? 'fill-amber-400' : ''}`} />
                      </button>
                    ))}
                    <span className="text-xs font-bold text-amber-400 ml-2">{reviewRating} / 5 Stars</span>
                  </div>

                  <div>
                    <textarea
                      rows={2}
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      placeholder="Write your feedback for W3C Digital Network..."
                      className="w-full p-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Review</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      )}

      {/* QR Code Pass Modal */}
      {showQRModal && activeBooking && (
        <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xs rounded-2xl bg-zinc-900 p-6 space-y-4 text-center shadow-2xl">
            <h3 className="text-base font-bold text-white">
              Appointment QR Ticket
            </h3>

            <div className="p-4 bg-white rounded-xl inline-block mx-auto">
              <img
                src={activeBooking.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${activeBooking.id}`}
                alt="Booking Check-In QR"
                className="w-44 h-44 object-contain"
              />
            </div>

            <p className="text-xs text-zinc-400">
              Present this QR code to <strong className="text-white">{activeBooking.businessName}</strong> upon check-in.
            </p>

            <button
              type="button"
              onClick={() => setShowQRModal(false)}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs"
            >
              Close Ticket
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
