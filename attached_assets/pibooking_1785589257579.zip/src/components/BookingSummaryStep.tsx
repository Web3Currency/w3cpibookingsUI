import React from 'react';
import { Service, BusinessProfile, PiUser } from '../types';
import { ArrowLeft, Calendar, Clock, User, Phone, FileText, Lock, ArrowRight, ShieldCheck, Paperclip } from 'lucide-react';
import { getUpcomingDays } from './SelectDateStep';
import { BookingProgressBar } from './BookingProgressBar';

interface AttachedFile {
  id: string;
  name: string;
  size: string;
  type: string;
  dataUrl?: string;
}

interface BookingSummaryStepProps {
  service: Service;
  business: BusinessProfile;
  selectedDate: string;
  selectedTimeSlot: string;
  clientDetails: {
    clientName: string;
    clientPiUsername: string;
    clientPhone: string;
    notes: string;
    attachments?: AttachedFile[];
  };
  piUser: PiUser | null;
  onBack: () => void;
  onProceedToPayment: () => void;
}

export const BookingSummaryStep: React.FC<BookingSummaryStepProps> = ({
  service,
  business,
  selectedDate,
  selectedTimeSlot,
  clientDetails,
  onBack,
  onProceedToPayment,
}) => {
  const availableDays = getUpcomingDays();
  const dateObj = availableDays.find((d) => d.dateStr === selectedDate) || availableDays[0];

  return (
    <div className="space-y-4 pb-28 animate-in fade-in slide-in-from-right-4 duration-200">
      {/* Consolidated 4-Step Progress Bar Header */}
      <BookingProgressBar currentStep={3} />

      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          id="btn-back-to-schedule-step"
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-zinc-800 text-zinc-200 text-xs font-semibold hover:bg-zinc-700 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
      </div>

      {/* Page Title */}
      <div>
        <h1 className="text-xl font-black text-white flex items-center gap-2">
          <FileText className="w-5 h-5 text-amber-400" />
          <span>Review Booking Summary</span>
        </h1>
        <p className="text-xs text-zinc-400 mt-1">
          Verify your appointment schedule & pioneer contact information before Pi payment.
        </p>
      </div>

      {/* Selected Service Card */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">
        <div className="flex items-center gap-3">
          {service.coverImageUrl && (
            <img
              src={service.coverImageUrl}
              alt={service.name}
              className="w-16 h-16 rounded-xl object-cover ring-1 ring-zinc-700 shrink-0"
            />
          )}
          <div className="min-w-0 flex-1">
            <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-wider block">
              {business.name}
            </span>
            <h2 className="text-base font-extrabold text-white truncate">
              {service.name}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Duration: {service.durationMinutes} mins • {service.locationType}
            </p>
          </div>
        </div>

        {/* Schedule Highlights */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-700/60 text-xs">
          <div className="p-2.5 rounded-xl bg-zinc-900/80 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-[10px] text-zinc-400 font-medium block">DATE</span>
              <span className="font-bold text-zinc-200 truncate block">
                {dateObj.dayName}, {dateObj.monthName} {dateObj.dayNum}
              </span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-zinc-900/80 flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-[10px] text-zinc-400 font-medium block">TIME SLOT</span>
              <span className="font-bold text-zinc-200 truncate block">{selectedTimeSlot}</span>
            </div>
          </div>
        </div>
      </div>      {/* Client Details Summary Card */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">

        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
          <User className="w-4 h-4 text-amber-400" />
          <span>Pioneer Client Details</span>
        </h3>

        <div className="space-y-2 text-xs">
          <div className="flex justify-between py-1 border-b border-zinc-700/40">
            <span className="text-zinc-400">Name:</span>
            <span className="font-bold text-white">{clientDetails.clientName}</span>
          </div>

          <div className="flex justify-between py-1 border-b border-zinc-700/40">
            <span className="text-zinc-400">Pi Username:</span>
            <span className="font-bold text-amber-300 font-mono">{clientDetails.clientPiUsername}</span>
          </div>

          <div className="flex justify-between py-1 border-b border-zinc-700/40">
            <span className="text-zinc-400">Phone / WhatsApp:</span>
            <span className="font-bold text-white">{clientDetails.clientPhone}</span>
          </div>

          {clientDetails.notes && (
            <div className="py-1">
              <span className="text-zinc-400 block mb-0.5">Appointment Notes:</span>
              <p className="p-2.5 rounded-xl bg-zinc-900 text-zinc-300 text-xs italic">
                "{clientDetails.notes}"
              </p>
            </div>
          )}

          {clientDetails.attachments && clientDetails.attachments.length > 0 && (
            <div className="py-1">
              <span className="text-zinc-400 block mb-1">Attached Wireframes / Specs ({clientDetails.attachments.length}):</span>
              <div className="space-y-1.5">
                {clientDetails.attachments.map((att) => (
                  <div key={att.id} className="p-2 rounded-lg bg-zinc-900 flex items-center gap-2 text-xs">
                    <Paperclip className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="font-medium text-zinc-200 truncate">{att.name}</span>
                    <span className="text-[10px] text-zinc-500 ml-auto">{att.size}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Price Breakdown Card */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-2 text-xs">
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1">
          Payment Breakdown (Pi Network)
        </h3>

        <div className="flex justify-between text-zinc-300">
          <span>Service Rate</span>
          <span className="font-bold">{service.pricePi.toFixed(2)} π</span>
        </div>

        <div className="flex justify-between text-zinc-300">
          <span>Pi Network Escrow Fee</span>
          <span className="font-bold text-emerald-400">0.00 π (Waived)</span>
        </div>

        <div className="pt-2 border-t border-zinc-700/60 flex justify-between items-center text-sm font-black text-white">
          <span>Total Payment Amount</span>
          <span className="text-amber-400 text-base">{service.pricePi.toFixed(2)} π</span>
        </div>
      </div>

      {/* Security Banner */}
      <div className="p-3.5 rounded-xl bg-amber-950/40 flex items-center gap-3">
        <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
        <div className="text-[11px] text-amber-200">
          <p className="font-bold">Secured by Pi Network Bridge</p>
          <p className="text-amber-300/80">
            Funds will be held securely in Pi escrow until deliverable review.
          </p>
        </div>
      </div>

      {/* Fixed Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-900/95 backdrop-blur-md border-t border-zinc-800 z-50">
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div className="text-xs">
            <span className="block text-zinc-400 text-[10px]">Step 3 of 4</span>
            <span className="text-lg font-black text-amber-400">
              {service.pricePi.toFixed(2)} π
            </span>
          </div>

          <button
            type="button"
            onClick={onProceedToPayment}
            id="btn-proceed-to-pi-payment"
            className="flex-1 py-3.5 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-sm active:scale-[0.98] transition flex items-center justify-center gap-2 min-h-[48px] shadow-lg shadow-amber-500/10"
          >
            <Lock className="w-4 h-4 stroke-[2.5]" />
            <span>Proceed to Pi Pay</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
