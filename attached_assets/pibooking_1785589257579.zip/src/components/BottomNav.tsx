import React from 'react';
import { Compass, CalendarCheck } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'browse' | 'bookings';
  onSelectTab: (tab: 'browse' | 'bookings') => void;
  bookingsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  bookingsCount,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-zinc-900/95 backdrop-blur-lg border-t border-zinc-800 transition-colors">
      <div className="max-w-md mx-auto grid grid-cols-2 h-16 px-4">
        {/* Tab 1: Browse Services */}
        <button
          onClick={() => onSelectTab('browse')}
          id="nav-tab-browse"
          className={`flex flex-col items-center justify-center gap-1 relative h-full transition-all ${
            activeTab === 'browse'
              ? 'text-amber-400 font-bold'
              : 'text-zinc-400 font-medium hover:text-zinc-200'
          }`}
        >
          <Compass className={`w-5 h-5 ${activeTab === 'browse' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-xs tracking-tight">Browse Services</span>
          {activeTab === 'browse' && (
            <span className="absolute top-0 w-8 h-1 rounded-b-full bg-amber-400" />
          )}
        </button>

        {/* Tab 2: My Bookings */}
        <button
          onClick={() => onSelectTab('bookings')}
          id="nav-tab-bookings"
          className={`flex flex-col items-center justify-center gap-1 relative h-full transition-all ${
            activeTab === 'bookings'
              ? 'text-amber-400 font-bold'
              : 'text-zinc-400 font-medium hover:text-zinc-200'
          }`}
        >
          <div className="relative">
            <CalendarCheck className={`w-5 h-5 ${activeTab === 'bookings' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {bookingsCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-500 text-zinc-950 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                {bookingsCount}
              </span>
            )}
          </div>
          <span className="text-xs tracking-tight">My Bookings</span>
          {activeTab === 'bookings' && (
            <span className="absolute top-0 w-8 h-1 rounded-b-full bg-amber-400" />
          )}
        </button>
      </div>
    </nav>
  );
};
