import React, { useState } from 'react';
import { BusinessProfile } from '../types';
import {
  ArrowLeft,
  Star,
  MapPin,
  Sparkles,
  Award,
  Image as ImageIcon,
  X,
  Globe,
  Phone,
  Mail,
  MessageSquare,
  ShieldCheck,
  Lock,
} from 'lucide-react';

interface BusinessAboutViewProps {
  business: BusinessProfile;
  onBack: () => void;
  onOpenAdmin?: () => void;
}

export const BusinessAboutView: React.FC<BusinessAboutViewProps> = ({
  business,
  onBack,
  onOpenAdmin,
}) => {
  const [selectedGalleryImage, setSelectedGalleryImage] = useState<string | null>(null);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('All');

  const galleryList = business.galleryImages || [];
  const categories: string[] = ['All', ...Array.from(new Set(galleryList.map((item) => item.category) as string[]))];

  const filteredGallery =
    activeCategoryFilter === 'All'
      ? galleryList
      : galleryList.filter((item) => item.category === activeCategoryFilter);

  const xSocial = business.socials?.find(
    (s) => s.platform.toLowerCase().includes('twitter') || s.platform.toLowerCase().includes('x')
  );
  const telegramSocial = business.socials?.find(
    (s) => s.platform.toLowerCase().includes('telegram')
  );
  const piChatSocial = business.socials?.find(
    (s) => s.platform.toLowerCase().includes('pi') || s.url.includes('pinet.com')
  );
  const piChatUrl = piChatSocial?.url || 'https://profiles.pinet.com/profiles/adeyemojibola8';

  return (
    <div className="space-y-5 pb-24 animate-in fade-in slide-in-from-right-4 duration-200">
      {/* Navigation Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          id="btn-back-from-about"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-800 text-zinc-200 text-xs font-semibold hover:bg-zinc-700 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Services</span>
        </button>
      </div>

      {/* Hero Banner with Avatar & Compact Merchant Details */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-b from-zinc-800 to-zinc-900/90 p-5 space-y-4 shadow-xl">
        <div className="flex items-start gap-4">
          <div className="relative shrink-0">
            <div className="w-16 h-16 rounded-2xl bg-zinc-950 ring-2 ring-amber-500/50 p-0.5 overflow-hidden shadow-md">
              <img
                src={business.avatarUrl}
                alt={business.name}
                className="w-full h-full rounded-xl object-cover"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-zinc-800 flex items-center justify-center text-[9px] text-zinc-950 font-black" title="Active Merchant">
              ✓
            </span>
          </div>

          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-black text-white tracking-tight leading-snug">
              {business.name}
            </h1>
            <p className="text-xs text-amber-400 font-semibold mt-0.5">
              {business.tagline}
            </p>

            <div className="flex items-center gap-2 mt-2 text-xs">
              <span className="inline-flex items-center gap-1 font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-full text-[11px]">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                {business.rating}
              </span>
              <span className="text-zinc-400 text-[11px] font-medium">
                ({business.reviewsCount} verified reviews)
              </span>
            </div>
          </div>
        </div>

        <p className="text-xs text-zinc-300 leading-relaxed border-t border-zinc-700/50 pt-3">
          {business.bio}
        </p>

        {/* Quick Highlights Grid */}
        <div className="grid grid-cols-2 gap-2 pt-0.5 text-xs">
          <div className="p-2.5 rounded-xl bg-zinc-900/90 flex items-center gap-2.5 hover:bg-zinc-900 transition-colors">
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="min-w-0">
              <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider block">LOCATION</span>
              <span className="font-bold text-zinc-200 truncate block text-[11px]">{business.location}</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-zinc-900/90 flex items-center gap-2.5 hover:bg-zinc-900 transition-colors">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
              <Award className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="min-w-0">
              <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider block">PAYMENT</span>
              <span className="font-bold text-emerald-300 truncate block text-[11px]">Pi Network SDK</span>
            </div>
          </div>
        </div>

        {/* Compact Quick Actions & Contact Info */}
        <div className="pt-3.5 border-t border-zinc-700/60 space-y-3">
          {/* 4-Column Action Items with Micro-Labels & Brand Color Themes */}
          <div className="grid grid-cols-4 gap-2.5 p-2 rounded-2xl bg-zinc-900/60">
            {/* Website */}
            <a
              href={business.website || '#'}
              target="_blank"
              rel="noopener noreferrer"
              id="btn-quick-website"
              className="flex flex-col items-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-zinc-950 flex items-center justify-center transition-all duration-200 shadow-sm active:scale-95">
                <Globe className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-semibold text-zinc-400 group-hover:text-amber-300 transition-colors">
                Website
              </span>
            </a>

            {/* X / Twitter */}
            <a
              href={xSocial?.url || 'https://x.com'}
              target="_blank"
              rel="noopener noreferrer"
              id="btn-quick-x"
              className="flex flex-col items-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-zinc-900 text-zinc-200 group-hover:bg-zinc-100 group-hover:text-zinc-950 flex items-center justify-center transition-all duration-200 shadow-sm active:scale-95">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </div>
              <span className="text-[10px] font-semibold text-zinc-400 group-hover:text-zinc-200 transition-colors">
                X (Twitter)
              </span>
            </a>

            {/* Telegram */}
            <a
              href={telegramSocial?.url || 'https://t.me'}
              target="_blank"
              rel="noopener noreferrer"
              id="btn-quick-telegram"
              className="flex flex-col items-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-sky-500/10 text-sky-400 group-hover:bg-sky-500 group-hover:text-zinc-950 flex items-center justify-center transition-all duration-200 shadow-sm active:scale-95">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.02-1.96 1.25-5.54 3.67-.52.36-1 .54-1.43.53-.47-.01-1.37-.27-2.05-.49-.83-.27-1.49-.42-1.43-.88.03-.24.37-.49 1.02-.75 3.99-1.74 6.66-2.89 8.01-3.45 3.81-1.58 4.6-1.86 5.12-1.87.11 0 .37.03.54.17.14.12.18.28.2.45-.02.07-.02.24-.04.42z" />
                </svg>
              </div>
              <span className="text-[10px] font-semibold text-zinc-400 group-hover:text-sky-300 transition-colors">
                Telegram
              </span>
            </a>

            {/* Pi Chat */}
            <a
              href={piChatUrl}
              target="_blank"
              rel="noopener noreferrer"
              id="btn-quick-pichat"
              className="flex flex-col items-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-purple-500/10 text-purple-400 group-hover:bg-purple-600 group-hover:text-white flex items-center justify-center transition-all duration-200 shadow-sm active:scale-95 relative">
                <MessageSquare className="w-5 h-5 fill-purple-400/20 group-hover:fill-white/30" />
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-purple-500"></span>
                </span>
              </div>
              <span className="text-[10px] font-semibold text-purple-300 group-hover:text-purple-200 transition-colors">
                Pi Chat
              </span>
            </a>
          </div>

          {/* Contact Details Interactive Row */}
          <div className="flex items-center justify-between text-xs text-zinc-300 pt-1 font-medium gap-2">
            {business.phone ? (
              <a
                href={`tel:${business.phone.replace(/\s+/g, '')}`}
                id="link-phone-direct"
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-900/80 text-zinc-300 hover:text-emerald-300 hover:bg-emerald-500/10 transition-all duration-150 min-w-0"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate text-[11px] font-semibold">{business.phone}</span>
              </a>
            ) : <span />}

            {business.email ? (
              <a
                href={`mailto:${business.email}`}
                id="link-email-direct"
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-900/80 text-zinc-300 hover:text-sky-300 hover:bg-sky-500/10 transition-all duration-150 min-w-0"
              >
                <Mail className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span className="truncate text-[11px] font-semibold">{business.email}</span>
              </a>
            ) : <span />}
          </div>
        </div>
      </div>

      {/* Trust & Guarantee Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent space-y-2">
        <div className="flex items-center gap-2 text-xs font-black text-amber-300">
          <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400" />
          <span>PI NETWORK VERIFIED MERCHANT PROTOCOL</span>
        </div>
        <p className="text-xs text-zinc-300 leading-relaxed">
          Transactions are locked in escrow via Pi Wallet Smart SDK contracts. Guaranteed delivery or automatic Pi refund.
        </p>
        <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 pt-1 border-t border-zinc-800/80">
          <div className="flex items-center gap-1.5 min-w-0">
            <span>Merchant Wallet:</span>
            <span className="font-bold text-amber-400 truncate">{business.piWalletAddress}</span>
          </div>

          {onOpenAdmin && (
            <button
              type="button"
              onClick={onOpenAdmin}
              id="btn-open-merchant-portal"
              className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-400 hover:text-amber-300 font-sans font-bold text-[10px] flex items-center gap-1 transition shrink-0"
            >
              <Lock className="w-3 h-3 text-amber-400" />
              <span>Business Console</span>
            </button>
          )}
        </div>
      </div>

      {/* Business Gallery Section ("Galleria") */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-amber-400" />
            <span>Portfolio Galleria</span>
          </h2>
          <span className="text-xs text-zinc-400 font-medium">
            {galleryList.length} Showcase Items
          </span>
        </div>

        {/* Category Filters */}
        {categories.length > 1 && (
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
            {categories.map((cat) => {
              const isActive = activeCategoryFilter === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategoryFilter(cat)}
                  id={`btn-filter-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition whitespace-nowrap ${
                    isActive
                      ? 'bg-amber-500 text-zinc-950 shadow-sm'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        )}

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          {filteredGallery.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedGalleryImage(item.imageUrl)}
              id={`gallery-item-${item.id}`}
              className="group relative rounded-2xl overflow-hidden bg-zinc-900 aspect-4/3 cursor-pointer hover:ring-2 hover:ring-amber-500/50 transition shadow-md"
            >
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/70 to-transparent opacity-90 group-hover:opacity-100 transition" />
              <div className="absolute bottom-2.5 left-2.5 right-2.5 space-y-0.5">
                <span className="text-[9px] font-black uppercase tracking-wider text-amber-300 bg-zinc-950/90 px-2 py-0.5 rounded-md inline-block backdrop-blur-sm">
                  {item.category}
                </span>
                <p className="text-xs font-extrabold text-white truncate drop-shadow-md leading-tight">
                  {item.title}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full-Screen Lightbox Modal for Gallery */}
      {selectedGalleryImage && (
        <div className="fixed inset-0 z-50 bg-zinc-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="relative max-w-lg w-full rounded-2xl bg-zinc-900 overflow-hidden shadow-2xl space-y-0">
            <button
              onClick={() => setSelectedGalleryImage(null)}
              id="btn-close-lightbox"
              className="absolute top-3 right-3 z-10 p-2 rounded-full bg-zinc-950/80 text-white hover:bg-zinc-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={selectedGalleryImage}
              alt="Gallery Preview"
              className="w-full h-auto max-h-[70vh] object-contain bg-zinc-950"
            />
            <div className="p-4 bg-zinc-900 text-center space-y-2">
              <span className="text-xs font-bold text-amber-400">
                Official Portfolio Project Asset
              </span>
              <button
                onClick={() => setSelectedGalleryImage(null)}
                className="w-full py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

