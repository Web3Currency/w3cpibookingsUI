import React from 'react';
import { BusinessProfile, PiUser } from '../types';
import { Wallet } from 'lucide-react';

interface NavbarProps {
  currentBusiness: BusinessProfile;
  piUser: PiUser | null;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentBusiness,
  piUser,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-zinc-900/90 border-b border-zinc-800 transition-colors">
      <div className="max-w-md mx-auto px-4 py-2.5 flex items-center justify-between gap-2">
        {/* Business Identity Avatar & Name */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-zinc-950 ring-1 ring-amber-500/40 p-0.5 overflow-hidden flex items-center justify-center shrink-0 shadow-sm">
            <img
              src={currentBusiness.avatarUrl}
              alt={currentBusiness.name}
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <span className="font-extrabold text-sm text-white tracking-tight hidden sm:inline-block">
            {currentBusiness.name}
          </span>
        </div>

        {/* Action Pills */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Pi User Balance Pill */}
          <div
            title={`Pi Wallet: ${piUser?.username ?? 'Not connected'}`}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-zinc-800 text-zinc-200 text-xs font-semibold"
          >
            <Wallet className="w-3.5 h-3.5 text-amber-400" />
            <span>{piUser?.walletBalancePi !== undefined ? `${piUser.walletBalancePi.toFixed(1)} π` : '—'}</span>
          </div>
        </div>
      </div>
    </header>
  );
};

