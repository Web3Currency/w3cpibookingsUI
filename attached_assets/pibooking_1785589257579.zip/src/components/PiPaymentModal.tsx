import React, { useState } from 'react';
import { Service, BusinessProfile, Booking, PiUser } from '../types';
import { piPaymentService } from '../services/piPaymentService';
import { ArrowLeft, Wallet, ShieldCheck, Lock, Loader2, CheckCircle2, Sparkles, AlertCircle } from 'lucide-react';
import { BookingProgressBar } from './BookingProgressBar';

interface PiPaymentModalProps {
  service: Service;
  business: BusinessProfile;
  date: string;
  timeSlot: string;
  clientDetails: {
    clientName: string;
    clientPiUsername: string;
    clientPhone: string;
    notes: string;
    attachments?: { id: string; name: string; size: string; type: string; dataUrl?: string }[];
  };
  piUser: PiUser | null;
  onBack: () => void;
  onPaymentComplete: (booking: Booking) => void;
}

export const PiPaymentModal: React.FC<PiPaymentModalProps> = ({
  service,
  business,
  date,
  timeSlot,
  clientDetails,
  onBack,
  onPaymentComplete,
}) => {
  const [paymentStatus, setPaymentStatus] = useState<
    'idle' | 'processing' | 'confirming' | 'success' | 'error'
  >('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [simulatedTxHash, setSimulatedTxHash] = useState<string | null>(null);

  const handlePayNow = async () => {
    setPaymentStatus('processing');
    setErrorMessage(null);

    try {
      const memo = `Booking: ${service.name} with ${business.name} (${date} @ ${timeSlot})`;

      const paymentResult = await piPaymentService.executePayment({
        amountPi: service.pricePi,
        memo,
        metadata: {
          serviceId: service.id,
          businessId: business.id,
          date,
          timeSlot,
        },
      });

      setSimulatedTxHash(paymentResult.txHash);
      setPaymentStatus('confirming');

      setTimeout(() => {
        setPaymentStatus('success');

        const newBooking: Booking = {
          id: 'bk_' + Date.now() + '_' + Math.floor(1000 + Math.random() * 9000),
          serviceId: service.id,
          serviceName: service.name,
          durationMinutes: service.durationMinutes,
          basePrice: service.basePrice || service.priceNGN,
          currency: service.currency || 'NGN',
          priceNGN: service.basePrice || service.priceNGN,
          pricePi: service.pricePi,
          date,
          timeSlot,
          clientName: clientDetails.clientName,
          clientPiUsername: clientDetails.clientPiUsername,
          clientPhone: clientDetails.clientPhone,
          notes: clientDetails.notes,
          attachments: clientDetails.attachments,
          status: 'Confirmed',
          paymentStatus: 'Paid',
          createdAt: new Date().toISOString(),
          piTxHash: paymentResult.txHash,
        };

        setTimeout(() => {
          onPaymentComplete(newBooking);
        }, 1000);
      }, 1000);
    } catch (err: unknown) {
      setPaymentStatus('error');
      setErrorMessage(err instanceof Error ? err.message : 'Pi Wallet payment failed. Please try again.');
    }
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          disabled={paymentStatus === 'processing' || paymentStatus === 'confirming'}
          className="p-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white transition disabled:opacity-50"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <span className="text-xs font-extrabold text-amber-400 tracking-wider uppercase">
          Pi Network Secure Checkout
        </span>
        <div className="w-8" />
      </div>

      <BookingProgressBar currentStep={5} />

      <div className="p-5 rounded-2xl bg-zinc-800 space-y-5">
        <div className="flex items-center justify-between border-b border-zinc-700/60 pb-4">
          <div>
            <span className="text-xs text-zinc-400 block font-bold">Total Payment Amount</span>
            <div className="text-3xl font-black text-amber-400 font-mono tracking-tight flex items-center gap-1">
              <span>{service.pricePi}</span>
              <span className="text-lg text-amber-500">π</span>
            </div>
            <span className="text-xs text-zinc-400">≈ ₦{(service.basePrice || service.priceNGN).toLocaleString()} NGN</span>
          </div>

          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
            <Wallet className="w-6 h-6" />
          </div>
        </div>

        {paymentStatus === 'error' && errorMessage && (
          <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {paymentStatus === 'success' ? (
          <div className="p-6 text-center space-y-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto animate-bounce" />
            <h4 className="font-extrabold text-white text-base">Payment Validated!</h4>
            <p className="text-xs text-zinc-300 font-mono break-all bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
              TxHash: {simulatedTxHash}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-700/60 space-y-2 text-xs">
              <div className="flex items-center justify-between text-zinc-400">
                <span>Merchant Receiver:</span>
                <span className="font-extrabold text-zinc-200">{business.name}</span>
              </div>
              <div className="flex items-center justify-between text-zinc-400">
                <span>Pi Wallet Address:</span>
                <span className="font-mono text-[11px] text-amber-400">{business.piWalletAddress}</span>
              </div>
            </div>

            <button
              onClick={handlePayNow}
              disabled={paymentStatus === 'processing' || paymentStatus === 'confirming'}
              className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] shadow-lg shadow-amber-500/20 disabled:opacity-50"
            >
              {paymentStatus === 'processing' || paymentStatus === 'confirming' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authorizing Pi Blockchain...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Confirm & Pay {service.pricePi} π</span>
                </>
              )}
            </button>
          </div>
        )}

        <div className="flex items-center justify-center gap-2 text-[11px] text-zinc-400 pt-2 border-t border-zinc-700/40">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>Encrypted via Pi Network Sandbox v2.0 Bridge</span>
        </div>
      </div>
    </div>
  );
};
