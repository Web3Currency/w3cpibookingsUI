import React, { useState } from 'react';
import { Service, TimeSlotOption } from '../types';
import { ArrowLeft, Calendar as CalendarIcon, Clock, ArrowRight, Sparkles, Check } from 'lucide-react';
import { BookingProgressBar } from './BookingProgressBar';
import { getUpcomingDays } from './SelectDateStep';

interface SelectScheduleStepProps {
  service: Service;
  initialDate?: string;
  initialTimeSlot?: string;
  onBack: () => void;
  onConfirmSchedule: (dateStr: string, timeSlot: string) => void;
}

const TIME_SLOTS_AVAILABLE: TimeSlotOption[] = [
  { time: '09:00 AM', available: true },
  { time: '10:00 AM', available: true },
  { time: '11:30 AM', available: true },
  { time: '01:00 PM', available: true },
  { time: '02:30 PM', available: true },
  { time: '03:45 PM', available: true },
  { time: '05:30 PM', available: true },
  { time: '07:00 PM', available: true },
];

export const SelectScheduleStep: React.FC<SelectScheduleStepProps> = ({
  service,
  initialDate,
  initialTimeSlot,
  onBack,
  onConfirmSchedule,
}) => {
  const availableDays = getUpcomingDays();
  const [selectedDate, setSelectedDate] = useState<string>(
    initialDate || availableDays[0].dateStr
  );
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>(
    initialTimeSlot || '02:30 PM'
  );

  const selectedDayObj = availableDays.find((d) => d.dateStr === selectedDate) || availableDays[0];

  return (
    <div className="space-y-4 pb-28 animate-in fade-in slide-in-from-right-4 duration-200">
      {/* Consolidated 4-Step Visual Progress Bar Header */}
      <BookingProgressBar currentStep={2} />

      {/* Top Header / Back Button (No redundant Step X of Y badge) */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          id="btn-back-to-details"
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-zinc-800 text-zinc-200 text-xs font-semibold hover:bg-zinc-700 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
      </div>

      {/* Page Title */}
      <div>
        <h1 className="text-xl font-black text-white flex items-center gap-2">
          <CalendarIcon className="w-5 h-5 text-amber-400" />
          <span>Select Date & Time</span>
        </h1>
        <p className="text-xs text-zinc-400 mt-1">
          Service: <strong className="text-zinc-200">{service.name}</strong> ({service.durationMinutes} mins)
        </p>
      </div>

      {/* Horizontal Scrollable Calendar Strip */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-zinc-400">
          <span className="uppercase tracking-wider">
            {selectedDayObj.monthName.toUpperCase()} 2026
          </span>
          <span className="text-amber-400 text-[11px] font-semibold flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> Next 10 Days
          </span>
        </div>

        {/* Horizontal Swipe/Scroll Strip */}
        <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-none snap-x snap-mandatory">
          {availableDays.map((d) => {
            const isSelected = d.dateStr === selectedDate;
            return (
              <button
                key={d.dateStr}
                type="button"
                onClick={() => setSelectedDate(d.dateStr)}
                id={`date-strip-${d.dateStr}`}
                className={`flex-shrink-0 w-20 py-3 rounded-xl transition text-center snap-start ${
                  isSelected
                    ? 'bg-amber-500 text-zinc-950 font-black shadow-lg shadow-amber-500/20 scale-[1.02]'
                    : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-700/60'
                }`}
              >
                <span className={`block text-[10px] uppercase font-extrabold tracking-wider ${
                  isSelected ? 'text-zinc-950' : 'text-zinc-400'
                }`}>
                  {d.dayName}
                </span>
                <span className="text-xl font-black block my-0.5">{d.dayNum}</span>
                <span className={`block text-[9px] font-bold ${
                  isSelected ? 'text-zinc-900' : 'text-zinc-500'
                }`}>
                  {d.monthName}
                </span>
              </button>
            );
          })}
        </div>

        {/* Date Selection Readout Badge */}
        <div className="pt-2 border-t border-zinc-700/60 flex items-center justify-between text-xs">
          <span className="text-zinc-400 font-medium text-[11px]">Selected Date:</span>
          <span className="font-bold text-amber-300">
            {selectedDayObj.fullDayName}, {selectedDayObj.monthName} {selectedDayObj.dayNum}, 2026
          </span>
        </div>
      </div>

      {/* Available Time Slots Section */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-zinc-400">
          <span className="uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Available Time Slots</span>
          </span>
          <span className="text-emerald-400 text-[11px] font-semibold">Real-time Openings</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {TIME_SLOTS_AVAILABLE.map((slot) => {
            const isSelected = selectedTimeSlot === slot.time;
            return (
              <button
                key={slot.time}
                type="button"
                onClick={() => setSelectedTimeSlot(slot.time)}
                id={`slot-${slot.time.replace(/[: ]/g, '-')}`}
                className={`py-3 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  isSelected
                    ? 'bg-amber-500 text-zinc-950 font-black shadow-md shadow-amber-500/10'
                    : 'bg-zinc-900 text-zinc-200 hover:bg-zinc-700/60'
                }`}
              >
                {isSelected && <Check className="w-3.5 h-3.5 stroke-[3] text-zinc-950" />}
                <span>{slot.time}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Combined Selection Summary Box */}
      <div className="p-3.5 rounded-xl bg-zinc-800/80 flex items-center justify-between text-xs">
        <div>
          <span className="text-zinc-400 block text-[10px] uppercase font-bold">Appointment Schedule</span>
          <span className="text-xs font-bold text-white">
            {selectedDayObj.dayName}, {selectedDayObj.monthName} {selectedDayObj.dayNum} @ {selectedTimeSlot}
          </span>
        </div>
        <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-300 font-bold text-[11px]">
          Ready
        </span>
      </div>

      {/* Fixed Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-900/95 backdrop-blur-md border-t border-zinc-800 z-50">
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div className="text-xs min-w-0">
            <span className="block text-zinc-400 text-[10px]">Step 2 of 4</span>
            <span className="font-bold text-white truncate block text-xs">
              {selectedDayObj.dayName}, {selectedDayObj.monthName} {selectedDayObj.dayNum} @ {selectedTimeSlot}
            </span>
          </div>

          <button
            type="button"
            onClick={() => onConfirmSchedule(selectedDate, selectedTimeSlot)}
            id="btn-confirm-schedule-step"
            className="flex-1 py-3.5 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-sm active:scale-[0.98] transition flex items-center justify-center gap-2 min-h-[48px] shadow-lg shadow-amber-500/10"
          >
            <span>Next: Review Summary</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
