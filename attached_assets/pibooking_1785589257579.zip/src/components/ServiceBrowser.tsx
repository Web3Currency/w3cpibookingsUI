import React, { useState } from 'react';
import { Service, BusinessProfile, CategoryId } from '../types';
import { Search, Clock, ArrowRight, Star, Sparkles, CheckCircle2, Filter, Check } from 'lucide-react';

interface ServiceBrowserProps {
  business: BusinessProfile;
  onSelectService: (service: Service) => void;
  onOpenAbout: () => void;
}

const DEFAULT_CATEGORY_LABELS: Record<string, string> = {
  landing_page: 'Landing Pages',
  web_dev: 'Websites & Apps',
  ux_design: 'UI/UX & Audits',
  pi_sdk: 'Pi SDK & Web3',
};

export const ServiceBrowser: React.FC<ServiceBrowserProps> = ({ business, onSelectService, onOpenAbout }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId | 'all'>('all');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Compute categories dynamically from active business services
  const uniqueCategories: string[] = Array.from(new Set(business.services.map((s) => String(s.category))));
  const categoriesList = [
    { id: 'all', label: 'All Services' },
    ...uniqueCategories.map((catId) => ({
      id: catId,
      label: DEFAULT_CATEGORY_LABELS[catId] || catId.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()),
    })),
  ];

  const filteredServices = business.services.filter((service) => {
    const matchesSearch =
      service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Hero Card with Image Cover Background & Dark Gradient Overlay */}
      <div className="relative rounded-2xl overflow-hidden text-white shadow-md aspect-square flex flex-col justify-end">
        {/* Background Image */}
        <img
          src="https://i.imgur.com/WuLX00c.png"
          alt="Pi Services Cover"
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        {/* Dark Gradient Overlay from bottom */}
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-zinc-950/30" />

        {/* Content Overlaid on Dark Gradient */}
        <div className="p-4 relative z-10 space-y-1.5">
          <h1 className="text-xl font-black tracking-tight text-white drop-shadow-md">{business.name}</h1>
          <p className="text-xs text-zinc-200 line-clamp-2 leading-relaxed drop-shadow-sm">{business.bio}</p>

          <div className="pt-2.5 border-t border-zinc-700/80 flex items-center justify-between text-xs text-zinc-300">
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="font-bold text-white">{business.rating}</span>
              <span className="text-zinc-300 font-medium">({business.reviewsCount} reviews)</span>
            </div>
            
            {/* Learn More Button */}
            <button
              onClick={onOpenAbout}
              id="btn-learn-more-business"
              className="flex items-center gap-1 text-xs bg-amber-500 hover:bg-amber-400 text-zinc-950 px-3 py-1 rounded-full font-black transition shadow-sm active:scale-95 cursor-pointer"
            >
              <span>Learn More</span>
              <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </div>

      {/* Search Input with Integrated Filter Button */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
        <input
          type="text"
          placeholder="Search services or keywords..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-12 py-2.5 rounded-xl bg-zinc-800 text-white placeholder-zinc-400 text-sm focus:ring-1 focus:ring-amber-500 focus:outline-none transition-all"
        />

        {/* Clickable Filter Icon on Right Side of Search Box */}
        <button
          type="button"
          onClick={() => setIsFilterOpen(!isFilterOpen)}
          id="btn-toggle-filter"
          title="Filter by Category"
          className={`absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1 ${
            selectedCategory !== 'all'
              ? 'bg-amber-500 text-zinc-950 font-bold shadow-xs'
              : 'bg-zinc-700/60 text-zinc-300 hover:bg-zinc-700'
          }`}
        >
          <Filter className="w-4 h-4" />
          {selectedCategory !== 'all' && (
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-950" />
          )}
        </button>

        {/* Filter Dropdown Popover */}
        {isFilterOpen && (
          <>
            {/* Backdrop for closing popover */}
            <div
              className="fixed inset-0 z-20"
              onClick={() => setIsFilterOpen(false)}
            />
            <div className="absolute right-0 top-full mt-2 z-30 w-56 p-1.5 rounded-xl bg-zinc-800/95 backdrop-blur-md shadow-2xl space-y-0.5">
              <div className="px-2.5 py-1.5 text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Filter Category</span>
                {selectedCategory !== 'all' && (
                  <button
                    onClick={() => {
                      setSelectedCategory('all');
                      setIsFilterOpen(false);
                    }}
                    className="text-amber-400 hover:underline capitalize"
                  >
                    Clear
                  </button>
                )}
              </div>
              {categoriesList.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setIsFilterOpen(false);
                  }}
                  className={`w-full px-2.5 py-2 rounded-lg text-xs font-medium text-left transition flex items-center justify-between ${
                    selectedCategory === cat.id
                      ? 'bg-amber-500/20 text-amber-300 font-bold'
                      : 'text-zinc-200 hover:bg-zinc-700/60'
                  }`}
                >
                  <span>{cat.label}</span>
                  {selectedCategory === cat.id && (
                    <Check className="w-3.5 h-3.5 text-amber-400" />
                  )}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Service List / Density Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold text-zinc-400 px-1">
          <span>{filteredServices.length} AVAILABLE SERVICES</span>
          <span>TAP TO VIEW & BOOK</span>
        </div>

        {filteredServices.length === 0 ? (
          <div className="text-center py-10 px-4 rounded-2xl bg-zinc-800">
            <p className="text-sm text-zinc-400 font-medium">No services match your search.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="mt-2 text-xs text-amber-400 font-semibold underline"
            >
              Reset filters
            </button>
          </div>
        ) : (
          filteredServices.map((service) => (
            <div
              key={service.id}
              onClick={() => onSelectService(service)}
              id={`service-card-${service.id}`}
              className="group p-3.5 rounded-xl bg-zinc-800 hover:bg-zinc-700/90 active:scale-[0.99] transition cursor-pointer flex items-center justify-between gap-3 min-h-[68px]"
            >
              {/* Service Info - 3 Key Data Points: Name, Duration, Price */}
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-white text-sm group-hover:text-amber-300 transition truncate">
                    {service.name}
                  </h3>
                  {service.featured && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 rounded shrink-0">
                      Popular
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3 mt-1 text-xs text-zinc-400">
                  {/* Data Point 2: Duration */}
                  <span className="flex items-center gap-1 font-medium">
                    <Clock className="w-3.5 h-3.5 text-zinc-400" />
                    {service.durationMinutes} mins
                  </span>

                  <span className="text-zinc-600">•</span>

                  {/* Location badge */}
                  <span className="truncate">{service.locationType}</span>
                </div>
              </div>

              {/* Data Point 3: Price in Pi & Action CTA */}
              <div className="flex items-center gap-2 shrink-0">
                <div className="text-right">
                  <div className="text-base font-extrabold text-amber-400 tracking-tight">
                    {service.pricePi} <span className="text-xs font-bold text-amber-500">π</span>
                  </div>
                </div>

                <div className="w-8 h-8 rounded-full bg-zinc-700 text-zinc-200 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-zinc-950 transition">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

