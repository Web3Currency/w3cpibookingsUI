import React from 'react';
import { Service, BusinessProfile } from '../types';
import { ArrowLeft, Clock, CheckCircle, UserCheck, MapPin, Calendar } from 'lucide-react';
import { BookingProgressBar } from './BookingProgressBar';

interface ServiceDetailProps {
  service: Service;
  business: BusinessProfile;
  onBack: () => void;
  onProceedToBooking: () => void;
}

export const ServiceDetail: React.FC<ServiceDetailProps> = ({
  service,
  business,
  onBack,
  onProceedToBooking,
}) => {
  const coverImage = service.coverImageUrl || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80';

  return (
    <div className="space-y-4 pb-28 animate-in fade-in slide-in-from-right-4 duration-200">
      {/* 5-Step Visual Progress Bar Header */}
      <BookingProgressBar currentStep={1} />

      {/* Top Header / Back Action */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          id="btn-back-to-browse"
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-zinc-800 text-zinc-200 text-xs font-semibold hover:bg-zinc-700 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Services</span>
        </button>
      </div>

      {/* Hero Cover Image Card */}
      <div className="relative rounded-2xl overflow-hidden bg-zinc-800 shadow-md">
        <div className="h-48 sm:h-56 w-full relative">
          <img
            src={coverImage}
            alt={service.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />
        </div>

        <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3">
          <div>
            <span className="inline-block px-2.5 py-0.5 rounded-md bg-amber-500 text-zinc-950 text-[10px] font-black uppercase tracking-wider mb-1.5">
              {service.category.replace('_', ' ')}
            </span>
            <h1 className="text-xl font-black text-white leading-tight drop-shadow-sm">
              {service.name}
            </h1>
          </div>
          <div className="text-right shrink-0">
            <div className="text-2xl font-black text-amber-400 drop-shadow-sm">
              {service.pricePi} <span className="text-sm font-bold text-amber-500">π</span>
            </div>
          </div>
        </div>
      </div>

      {/* Service Overview Box */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">
        <div className="flex items-center justify-between text-xs text-zinc-400">
          <span>Provided by <strong className="text-zinc-200">{business.name}</strong></span>
        </div>

        <p className="text-xs text-zinc-300 leading-relaxed pt-1">
          {service.description}
        </p>

        {/* Quick Meta Stats */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-700/60 text-xs">
          <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-zinc-900/60">
            <Clock className="w-4.5 h-4.5 text-amber-400 shrink-0" />
            <div>
              <span className="block text-[10px] text-zinc-400 font-medium">ESTIMATED DURATION</span>
              <span className="font-bold text-zinc-200">{service.durationMinutes} minutes</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-zinc-900/60">
            <MapPin className="w-4.5 h-4.5 text-amber-400 shrink-0" />
            <div className="min-w-0">
              <span className="block text-[10px] text-zinc-400 font-medium">LOCATION / MODE</span>
              <span className="font-bold text-zinc-200 truncate block">
                {service.locationType}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* What's Included Breakdown */}
      <div className="p-4 rounded-2xl bg-zinc-800 space-y-3">
        <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
          <span>WHAT IS INCLUDED IN THIS SESSION</span>
        </h2>
        <ul className="space-y-2.5">
          {service.included.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-xs text-zinc-200 font-medium">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Provider & Trust Card */}
      <div className="p-4 rounded-2xl bg-zinc-800 flex items-center gap-3">
        <img
          src={business.avatarUrl}
          alt={service.providerName}
          className="w-11 h-11 rounded-full object-cover ring-1 ring-zinc-700 shrink-0"
        />
        <div className="min-w-0 flex-1 text-xs">
          <div className="flex items-center gap-1 font-bold text-white">
            <UserCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>{service.providerName}</span>
          </div>
          <p className="text-zinc-400 mt-0.5">{service.providerRole}</p>
        </div>
      </div>

      {/* Fixed Sticky Bottom Action Bar with Prominent "Book Now" Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-900/95 backdrop-blur-md border-t border-zinc-800 z-50">
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div className="text-xs">
            <span className="block text-zinc-400">Service Price</span>
            <span className="text-xl font-black text-white">
              {service.pricePi} <span className="text-xs font-bold text-amber-500">π</span>
            </span>
          </div>

          <button
            onClick={onProceedToBooking}
            id="btn-book-now"
            className="flex-1 py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-sm active:scale-[0.98] transition flex items-center justify-center gap-2 min-h-[48px] shadow-lg shadow-amber-500/10"
          >
            <Calendar className="w-4.5 h-4.5 stroke-[2.5]" />
            <span>Book Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};
