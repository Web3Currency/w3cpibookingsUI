import React, { useState, useEffect } from 'react';
import { useBusiness } from '../../hooks/useBusiness';
import { useServices } from '../../hooks/useServices';
import { useBookings } from '../../hooks/useBookings';
import { useExchangeRate } from '../../hooks/useExchangeRate';
import { useAuth } from '../../hooks/useAuth';
import { customerService } from '../../services/customerService';
import { Service, BookingStatus, Customer, ServiceStatus, BusinessHours } from '../../types';
import { isSupabaseConfigured } from '../../lib/supabase';
import {
  DollarSign,
  Plus,
  Trash2,
  Edit2,
  RefreshCw,
  Clock,
  Calendar,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  User,
  Phone,
  Mail,
  ShieldCheck,
  Save,
  Key,
  Users,
  LogOut,
  Tag,
  BarChart3,
  Globe,
  Wallet,
  Building,
} from 'lucide-react';

interface BusinessConsoleViewProps {
  onExitConsole: () => void;
  onDataChanged?: () => void;
}

export const BusinessConsoleView: React.FC<BusinessConsoleViewProps> = ({
  onExitConsole,
  onDataChanged,
}) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'services' | 'bookings' | 'customers' | 'pricing' | 'profile' | 'hours' | 'settings'
  >('overview');

  const { business, updateBusiness, refreshBusiness } = useBusiness();
  const { services, addService, updateService, deleteService, refreshServices } = useServices();
  const { bookings, updateBookingStatus, refreshBookings } = useBookings();
  const { exchangeRateNGN, updateExchangeRate, refreshExchangeRate } = useExchangeRate();
  const { passcode, updatePasscode, logout } = useAuth();

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [inputRate, setInputRate] = useState<string>('3500');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  // Service Edit / Add Form
  const [isServiceFormOpen, setIsServiceFormOpen] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [shortDesc, setShortDesc] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [deliverablesStr, setDeliverablesStr] = useState('');
  const [duration, setDuration] = useState('60');
  const [basePrice, setBasePrice] = useState('150000');
  const [serviceStatus, setServiceStatus] = useState<ServiceStatus>('Published');
  const [category, setCategory] = useState('web_dev');

  // Service Delete Confirmation State
  const [deletingService, setDeletingService] = useState<{ id: string; name: string } | null>(null);
  const [isDeletingService, setIsDeletingService] = useState(false);

  // Business Profile Form
  const [bName, setBName] = useState(business.name);
  const [bTagline, setBTagline] = useState(business.tagline);
  const [bPhone, setBPhone] = useState(business.phone);
  const [bEmail, setBEmail] = useState(business.email);
  const [bBio, setBBio] = useState(business.bio);
  const [bWallet, setBWallet] = useState(business.piWalletAddress);
  const [bWebsite, setBWebsite] = useState(business.website);

  // Business Hours Form
  const [hours, setHours] = useState<BusinessHours>(business.businessHours);

  // Passcode Security Form
  const [newPasscode, setNewPasscode] = useState('');

  useEffect(() => {
    setInputRate(exchangeRateNGN.toString());
  }, [exchangeRateNGN]);

  useEffect(() => {
    setBName(business.name);
    setBTagline(business.tagline);
    setBPhone(business.phone);
    setBEmail(business.email);
    setBBio(business.bio);
    setBWallet(business.piWalletAddress);
    setBWebsite(business.website);
    if (business.businessHours) {
      setHours(business.businessHours);
    }
  }, [business]);

  useEffect(() => {
    customerService.getCustomersAsync().then(setCustomers);
  }, [bookings]);

  const showToast = (msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(null), 4000);
  };

  const handleRefreshAll = async () => {
    await Promise.all([
      refreshBusiness(),
      refreshServices(),
      refreshBookings(),
      refreshExchangeRate(),
      customerService.getCustomersAsync().then(setCustomers),
    ]);
    if (onDataChanged) onDataChanged();
    showToast('Console data refreshed from database.');
  };

  const handleSaveRate = async (e: React.FormEvent) => {
    e.preventDefault();
    const rate = parseFloat(inputRate);
    if (!rate || rate <= 0) return;
    await updateExchangeRate(rate);
    await refreshServices();
    if (onDataChanged) onDataChanged();
    showToast(`Exchange rate updated! 1 Pi = ₦${rate.toLocaleString()} NGN.`);
  };

  const handleOpenAddService = () => {
    setEditingServiceId(null);
    setTitle('');
    setShortDesc('');
    setCoverImage('https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80');
    setDeliverablesStr('Custom UI design & modern layout\nMobile & tablet optimization\nSEO setup');
    setDuration('60');
    setBasePrice('150000');
    setServiceStatus('Published');
    setCategory('web_dev');
    setIsServiceFormOpen(true);
  };

  const handleOpenEditService = (s: Service) => {
    setEditingServiceId(s.id);
    setTitle(s.name);
    setShortDesc(s.description);
    setCoverImage(s.coverImageUrl || '');
    setDeliverablesStr(s.included.join('\n'));
    setDuration(s.durationMinutes.toString());
    setBasePrice((s.basePrice || s.priceNGN).toString());
    setServiceStatus(s.status || 'Published');
    setCategory(s.category);
    setIsServiceFormOpen(true);
  };

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const deliverables = deliverablesStr
      .split('\n')
      .map((item) => item.trim())
      .filter(Boolean);

    const numericPrice = parseFloat(basePrice) || 100000;
    const numericDuration = parseInt(duration, 10) || 60;

    if (editingServiceId) {
      await updateService(editingServiceId, {
        name: title.trim(),
        description: shortDesc.trim(),
        coverImageUrl: coverImage.trim(),
        included: deliverables,
        durationMinutes: numericDuration,
        basePrice: numericPrice,
        priceNGN: numericPrice,
        currency: 'NGN',
        status: serviceStatus,
        category,
      });
      showToast('Service updated successfully.');
    } else {
      await addService({
        name: title.trim(),
        description: shortDesc.trim(),
        coverImageUrl: coverImage.trim(),
        included: deliverables,
        durationMinutes: numericDuration,
        basePrice: numericPrice,
        currency: 'NGN',
        priceNGN: numericPrice,
        pricePi: parseFloat((numericPrice / exchangeRateNGN).toFixed(2)),
        featured: false,
        providerName: 'Alex Rivera',
        providerRole: 'Lead Specialist',
        locationType: 'Online / Remote',
        status: serviceStatus,
        category,
      });
      showToast('New service added to catalog.');
    }

    setIsServiceFormOpen(false);
    if (onDataChanged) onDataChanged();
  };

  const confirmDeleteService = async () => {
    if (!deletingService) return;
    setIsDeletingService(true);
    try {
      await deleteService(deletingService.id);
      if (onDataChanged) onDataChanged();
      showToast(`Service "${deletingService.name}" deleted.`);
    } catch (err) {
      console.error('[Delete Error]', err);
      showToast('Failed to delete service');
    } finally {
      setIsDeletingService(false);
      setDeletingService(null);
    }
  };

  const handleStatusChange = async (id: string, status: BookingStatus) => {
    await updateBookingStatus(id, status);
    if (onDataChanged) onDataChanged();
    showToast(`Booking status changed to ${status}.`);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateBusiness({
      name: bName,
      tagline: bTagline,
      phone: bPhone,
      email: bEmail,
      bio: bBio,
      piWalletAddress: bWallet,
      website: bWebsite,
    });
    if (onDataChanged) onDataChanged();
    showToast('Business Profile updated.');
  };

  const handleSaveHours = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateBusiness({ businessHours: hours });
    if (onDataChanged) onDataChanged();
    showToast('Business hours saved successfully.');
  };

  const handleUpdatePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPasscode.trim().length < 4) {
      alert('Passcode must be at least 4 characters long.');
      return;
    }
    updatePasscode(newPasscode.trim());
    setNewPasscode('');
    showToast('Admin passcode updated.');
  };

  // Metrics
  const totalRevenuePi = bookings.reduce((sum, b) => sum + (b.pricePi || 0), 0);
  const totalRevenueNGN = bookings.reduce((sum, b) => sum + (b.basePrice || b.priceNGN || 0), 0);
  const completedBookings = bookings.filter((b) => b.status === 'Completed').length;
  const confirmedBookings = bookings.filter((b) => b.status === 'Confirmed').length;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans">
      {/* Top Banner Bar */}
      <header className="bg-zinc-900/90 border-b border-zinc-800 sticky top-0 z-30 backdrop-blur-md px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onExitConsole}
            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm text-white tracking-wide">Pi Business OS</span>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-[10px] font-mono border border-amber-500/20">
                Console
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 hidden sm:block">
              {business.name} — Merchant Operating System
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefreshAll}
            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1.5 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Sync Data</span>
          </button>
          <button
            onClick={() => {
              logout();
              onExitConsole();
            }}
            className="p-2 rounded-xl bg-red-950/40 hover:bg-red-900/40 text-red-300 border border-red-500/20 text-xs flex items-center gap-1.5 transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Exit Console</span>
          </button>
        </div>
      </header>

      {/* Toast Notification */}
      {statusMsg && (
        <div className="fixed top-16 right-4 z-50 bg-amber-500 text-zinc-950 px-4 py-2.5 rounded-xl font-bold text-xs shadow-lg animate-in slide-in-from-top-2">
          {statusMsg}
        </div>
      )}

      {/* Main Grid Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Navigation Sidebar */}
        <aside className="md:col-span-1 space-y-1">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'services', label: 'Services Catalog', icon: Tag },
            { id: 'bookings', label: 'Bookings & Orders', icon: Calendar },
            { id: 'customers', label: 'Customer Directory', icon: Users },
            { id: 'pricing', label: 'Pricing & Exchange', icon: DollarSign },
            { id: 'profile', label: 'Business Profile', icon: Building },
            { id: 'hours', label: 'Business Hours', icon: Clock },
            { id: 'settings', label: 'Security & Access', icon: Key },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold transition text-left ${
                  isActive
                    ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/10'
                    : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Content Panel */}
        <main className="md:col-span-4 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-1">
                  <span className="text-xs text-zinc-400">Total Pi Revenue</span>
                  <div className="text-2xl font-black text-amber-400 font-mono flex items-center gap-1">
                    <span>{totalRevenuePi.toFixed(2)}</span>
                    <span className="text-xs">π</span>
                  </div>
                  <span className="text-[11px] text-zinc-500 block">≈ ₦{totalRevenueNGN.toLocaleString()} NGN</span>
                </div>

                <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-1">
                  <span className="text-xs text-zinc-400">Total Orders</span>
                  <div className="text-2xl font-black text-white font-mono">{bookings.length}</div>
                  <span className="text-[11px] text-emerald-400 block">{completedBookings} Completed</span>
                </div>

                <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-1">
                  <span className="text-xs text-zinc-400">Active Services</span>
                  <div className="text-2xl font-black text-white font-mono">{services.length}</div>
                  <span className="text-[11px] text-zinc-500 block">In Service Catalog</span>
                </div>

                <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-1">
                  <span className="text-xs text-zinc-400">Exchange Rate</span>
                  <div className="text-2xl font-black text-amber-400 font-mono">₦{exchangeRateNGN.toLocaleString()}</div>
                  <span className="text-[11px] text-zinc-500 block">Per 1 Pi Network Token</span>
                </div>
              </div>

              {/* Recent Orders List */}
              <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-extrabold text-white">Recent Orders & Bookings</h3>
                  <button
                    onClick={() => setActiveTab('bookings')}
                    className="text-xs font-bold text-amber-400 hover:underline"
                  >
                    View All ({bookings.length})
                  </button>
                </div>

                {bookings.length === 0 ? (
                  <p className="text-xs text-zinc-500 py-6 text-center">No bookings received yet.</p>
                ) : (
                  <div className="divide-y divide-zinc-800/60">
                    {bookings.slice(0, 5).map((b) => (
                      <div key={b.id} className="py-3 flex items-center justify-between text-xs">
                        <div>
                          <p className="font-bold text-white">{b.serviceName}</p>
                          <p className="text-[11px] text-zinc-400">
                            Client: @{b.clientPiUsername} • {b.date} at {b.timeSlot}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-amber-400">{b.pricePi} π</span>
                          <span className="block text-[10px] text-zinc-500">₦{(b.basePrice || b.priceNGN).toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: SERVICES CATALOG */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-extrabold text-white">Services Catalog</h3>
                  <p className="text-xs text-zinc-400">Manage your active offerings and pricing</p>
                </div>
                <button
                  onClick={handleOpenAddService}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 text-zinc-950 text-xs font-black flex items-center gap-1.5 transition hover:bg-amber-400 shadow-md shadow-amber-500/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Service</span>
                </button>
              </div>

              {isServiceFormOpen && (
                <form onSubmit={handleSaveService} className="p-5 sm:p-6 rounded-2xl bg-zinc-900 border border-amber-500/30 shadow-xl space-y-4 animate-in fade-in duration-200">
                  <h4 className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span>{editingServiceId ? 'Edit Service' : 'New Service Offering'}</span>
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">Service Title</label>
                      <input
                        type="text"
                        required
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="e.g. 1-Page SaaS Landing Page"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">Category</label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                      >
                        <option value="landing_page">Landing Page</option>
                        <option value="web_dev">Web Development</option>
                        <option value="ux_design">UI/UX Audit</option>
                        <option value="pi_sdk">Pi Payment SDK Setup</option>
                        <option value="consulting">Consulting</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">Base Price (NGN)</label>
                      <input
                        type="number"
                        required
                        value={basePrice}
                        onChange={(e) => setBasePrice(e.target.value)}
                        placeholder="150000"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs font-mono focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                      />
                      <span className="text-[11px] text-amber-400 mt-1 block font-medium">
                        Calculated Pi Price: {(parseFloat(basePrice || '0') / exchangeRateNGN).toFixed(2)} π
                      </span>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">Duration (Minutes)</label>
                      <input
                        type="number"
                        required
                        value={duration}
                        onChange={(e) => setDuration(e.target.value)}
                        placeholder="60"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs font-mono focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">Short Description</label>
                    <textarea
                      rows={2}
                      value={shortDesc}
                      onChange={(e) => setShortDesc(e.target.value)}
                      placeholder="Concise overview of what client receives"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">Included Deliverables (One per line)</label>
                    <textarea
                      rows={3}
                      value={deliverablesStr}
                      onChange={(e) => setDeliverablesStr(e.target.value)}
                      placeholder="Custom UI design&#10;Mobile responsiveness&#10;Domain setup"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all font-mono"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2.5 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsServiceFormOpen(false)}
                      className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-black flex items-center gap-1.5 transition-all active:scale-[0.98] shadow-md shadow-amber-500/20 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Service</span>
                    </button>
                  </div>
                </form>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {services.map((s) => (
                  <div key={s.id} className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between">
                        <h4 className="font-extrabold text-sm text-white">{s.name}</h4>
                        <span className="font-mono font-bold text-amber-400 text-sm">{s.pricePi} π</span>
                      </div>
                      <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{s.description}</p>
                      <div className="text-[11px] text-zinc-500 mt-2 flex items-center gap-3">
                        <span>Duration: {s.durationMinutes}m</span>
                        <span>Base: ₦{(s.basePrice || s.priceNGN).toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800/60">
                      <button
                        onClick={() => handleOpenEditService(s)}
                        className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => setDeletingService({ id: s.id, name: s.name })}
                        title="Delete service"
                        className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-300 text-xs flex items-center gap-1 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: BOOKINGS & ORDERS */}
          {activeTab === 'bookings' && (
            <div className="space-y-4">
              <h3 className="text-sm font-extrabold text-white">Bookings & Service Orders</h3>
              {bookings.length === 0 ? (
                <div className="p-8 rounded-2xl bg-zinc-900 border border-zinc-800 text-center text-zinc-500 text-xs">
                  No bookings registered yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {bookings.map((b) => (
                    <div key={b.id} className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-white">{b.serviceName}</span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              b.status === 'Completed'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : b.status === 'Confirmed'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {b.status}
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400">
                          Client: <span className="text-white font-medium">{b.clientName}</span> (@{b.clientPiUsername}) • {b.clientPhone}
                        </p>
                        <p className="text-xs text-zinc-400">
                          Date: <span className="text-zinc-300">{b.date}</span> at <span className="text-zinc-300">{b.timeSlot}</span>
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="font-mono font-black text-amber-400 text-sm">{b.pricePi} π</div>
                          <div className="text-[10px] text-zinc-500">₦{(b.basePrice || b.priceNGN).toLocaleString()}</div>
                        </div>

                        <select
                          value={b.status}
                          onChange={(e) => handleStatusChange(b.id, e.target.value as BookingStatus)}
                          className="px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white focus:outline-none focus:border-amber-500"
                        >
                          <option value="Confirmed">Confirmed</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CUSTOMERS DIRECTORY */}
          {activeTab === 'customers' && (
            <div className="space-y-4">
              <h3 className="text-sm font-extrabold text-white">Customer CRM Directory</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {customers.map((c) => (
                  <div key={c.id} className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-white">{c.name}</span>
                      <span className="font-mono text-xs text-amber-400">@{c.piUsername}</span>
                    </div>
                    <div className="text-xs text-zinc-400 flex items-center gap-3">
                      <span>Bookings: {c.totalBookings}</span>
                      <span>Total Spend: {c.totalSpendPi} π</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: PRICING & EXCHANGE */}
          {activeTab === 'pricing' && (
            <form onSubmit={handleSaveRate} className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 max-w-lg shadow-xl">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-amber-400" />
                <span>Global Exchange Rate Engine</span>
              </h3>
              <p className="text-xs text-zinc-400">
                Set the exchange rate of 1 Pi Network token in NGN. All service prices in Pi are calculated automatically based on this rate.
              </p>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">1 Pi Rate in NGN (₦)</label>
                <input
                  type="number"
                  value={inputRate}
                  onChange={(e) => setInputRate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white font-mono text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-amber-500 text-zinc-950 font-black text-xs flex items-center justify-center gap-1.5 hover:bg-amber-400 transition-all active:scale-[0.98] shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Exchange Rate</span>
              </button>
            </form>
          )}

          {/* TAB 6: BUSINESS PROFILE */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 shadow-xl">
              <h3 className="text-sm font-extrabold text-white">Business Profile Settings</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Business Name</label>
                  <input
                    type="text"
                    value={bName}
                    onChange={(e) => setBName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Tagline</label>
                  <input
                    type="text"
                    value={bTagline}
                    onChange={(e) => setBTagline(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={bPhone}
                    onChange={(e) => setBPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={bEmail}
                    onChange={(e) => setBEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Pi Merchant Wallet</label>
                  <input
                    type="text"
                    value={bWallet}
                    onChange={(e) => setBWallet(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs font-mono focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Website URL</label>
                  <input
                    type="text"
                    value={bWebsite}
                    onChange={(e) => setBWebsite(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Business Bio</label>
                <textarea
                  rows={3}
                  value={bBio}
                  onChange={(e) => setBBio(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs flex items-center gap-1.5 transition-all active:scale-[0.98] shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Business Profile</span>
              </button>
            </form>
          )}

          {/* TAB 7: BUSINESS HOURS & AVAILABILITY */}
          {activeTab === 'hours' && (
            <form onSubmit={handleSaveHours} className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 shadow-xl">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Business Operating Hours & Availability</span>
              </h3>
              <p className="text-xs text-zinc-400">Configure your daily working schedule for client appointments.</p>

              <div className="space-y-3">
                {(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const).map((day) => {
                  const dayData = hours[day] || { open: '09:00', close: '17:00', active: true };
                  return (
                    <div key={day} className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
                      <span className="font-bold capitalize w-24 text-white">{day}</span>

                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-1.5 cursor-pointer text-zinc-400 hover:text-white transition-colors">
                          <input
                            type="checkbox"
                            checked={dayData.active}
                            onChange={(e) =>
                              setHours({
                                ...hours,
                                [day]: { ...dayData, active: e.target.checked },
                              })
                            }
                            className="accent-amber-500"
                          />
                          <span>Open</span>
                        </label>

                        {dayData.active && (
                          <div className="flex items-center gap-2 font-mono">
                            <input
                              type="time"
                              value={dayData.open}
                              onChange={(e) =>
                                setHours({
                                  ...hours,
                                  [day]: { ...dayData, open: e.target.value },
                                })
                              }
                              className="px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500"
                            />
                            <span>to</span>
                            <input
                              type="time"
                              value={dayData.close}
                              onChange={(e) =>
                                setHours({
                                  ...hours,
                                  [day]: { ...dayData, close: e.target.value },
                                })
                              }
                              className="px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs focus:outline-none focus:border-amber-500"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs flex items-center gap-1.5 transition-all active:scale-[0.98] shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Schedule</span>
              </button>
            </form>
          )}

          {/* TAB 8: SECURITY & ACCESS */}
          {activeTab === 'settings' && (
            <form onSubmit={handleUpdatePasscodeSubmit} className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 max-w-lg shadow-xl">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span>Admin Passcode & Console Security</span>
              </h3>
              <p className="text-xs text-zinc-400">Change your business console unlock passcode.</p>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Current Passcode</label>
                <input
                  type="text"
                  disabled
                  value={passcode}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950/60 border border-zinc-800 text-zinc-400 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">New Passcode</label>
                <input
                  type="password"
                  value={newPasscode}
                  onChange={(e) => setNewPasscode(e.target.value)}
                  placeholder="Enter new 4+ character passcode"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-xs font-mono focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs flex items-center gap-1.5 transition-all active:scale-[0.98] shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Update Passcode</span>
              </button>
            </form>
          )}
        </main>
      </div>

      {/* DELETE SERVICE CONFIRMATION MODAL */}
      {deletingService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-red-950/80 rounded-xl border border-red-900/60 text-red-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base">Delete Service</h3>
                <p className="text-xs text-zinc-400">This action will remove the service from your catalog.</p>
              </div>
            </div>

            <p className="text-sm text-zinc-300">
              Are you sure you want to delete <span className="font-bold text-white">"{deletingService.name}"</span>?
            </p>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-800">
              <button
                type="button"
                onClick={() => setDeletingService(null)}
                disabled={isDeletingService}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteService}
                disabled={isDeletingService}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-500 text-white flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                {isDeletingService ? (
                  <span>Deleting...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Service</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
