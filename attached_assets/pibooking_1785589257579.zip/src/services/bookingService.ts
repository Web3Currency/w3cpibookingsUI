import { Booking, BookingStatus, PaymentStatus } from '../types';
import { supabase, isSupabaseConfigured, safeSupabaseInsert, safeSupabaseUpdate } from '../lib/supabase';
import { customerService } from './customerService';

const LOCAL_BOOKINGS_KEY = 'w3c_bookings';

function logRLSHint(tableName: string) {
  console.warn(
    `[Supabase RLS Warning] Operation on table '${tableName}' was blocked by Row Level Security.\n` +
    `To allow public read/write or authenticated admin access, execute this SQL in your Supabase SQL Editor:\n` +
    `CREATE POLICY "Allow public all" ON public.${tableName} FOR ALL USING (true) WITH CHECK (true);`
  );
}

export const bookingService = {
  getBookingsLocal(): Booking[] {
    const cached = localStorage.getItem(LOCAL_BOOKINGS_KEY);
    if (!cached) return [];
    try {
      return JSON.parse(cached);
    } catch {
      return [];
    }
  },

  async getBookingsAsync(): Promise<Booking[]> {
    const localBookings = this.getBookingsLocal();

    if (!isSupabaseConfigured()) {
      return localBookings;
    }

    console.log('[Supabase Request] Fetching bookings from table "bookings"...');

    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.warn('[Supabase Note] Failed to fetch bookings from database:', error.message);
        if (error.code === '42501') logRLSHint('bookings');
        return localBookings;
      }

      if (!data) return localBookings;

      console.log(`[Supabase Success] Received ${data.length} bookings from database.`);

      const remoteBookings: Booking[] = data.map((row: any) => ({
        id: row.id,
        serviceId: row.service_id || '',
        serviceName: row.service_title || row.service_name || 'Service',
        durationMinutes: row.duration_minutes || 60,
        basePrice: Number(row.base_price) || Number(row.price_ngn) || 0,
        currency: row.currency || 'NGN',
        priceNGN: Number(row.base_price) || Number(row.price_ngn) || 0,
        pricePi: Number(row.price_pi) || 0,
        date: row.booking_date || row.date,
        timeSlot: row.booking_time || row.time_slot,
        clientName: row.customer_name || row.client_name,
        clientPiUsername: row.customer_pi_username || row.client_pi_username,
        clientPhone: row.customer_phone || row.client_phone || '',
        clientEmail: row.customer_email || row.client_email,
        notes: row.notes,
        attachments: Array.isArray(row.attachments) ? row.attachments : [],
        status: (row.status || 'Confirmed') as BookingStatus,
        paymentStatus: (row.payment_status || 'Paid') as PaymentStatus,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        piTxHash: row.pi_tx_hash,
        rating: row.rating,
        reviewComment: row.review_comment,
        reviewDate: row.review_date,
      }));

      localStorage.setItem(LOCAL_BOOKINGS_KEY, JSON.stringify(remoteBookings));
      return remoteBookings;
    } catch (e: any) {
      console.error('[Supabase Exception] Error fetching bookings:', e?.message || e);
      return localBookings;
    }
  },

  async saveBookingAsync(newBooking: Omit<Booking, 'id'> & { id?: string }): Promise<Booking> {
    const id = newBooking.id || `bk_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;
    const fullBooking: Booking = {
      ...newBooking,
      id,
      basePrice: newBooking.basePrice || newBooking.priceNGN,
      priceNGN: newBooking.basePrice || newBooking.priceNGN,
      currency: newBooking.currency || 'NGN',
      paymentStatus: newBooking.paymentStatus || 'Paid',
      status: newBooking.status || 'Confirmed',
      createdAt: newBooking.createdAt || new Date().toISOString(),
    };

    // Register / update customer CRM record
    await customerService.trackCustomerActivityAsync({
      name: fullBooking.clientName,
      piUsername: fullBooking.clientPiUsername,
      phone: fullBooking.clientPhone,
      email: fullBooking.clientEmail,
      spendBase: fullBooking.basePrice,
      spendPi: fullBooking.pricePi,
      currency: fullBooking.currency,
    });

    if (isSupabaseConfigured()) {
      console.log(`[Supabase Request] Saving booking id="${fullBooking.id}" into Supabase...`);
      try {
        const payload: Record<string, any> = {
          status: fullBooking.status,
          customer_name: fullBooking.clientName,
          customer_pi_username: fullBooking.clientPiUsername,
          customer_phone: fullBooking.clientPhone,
          customer_email: fullBooking.clientEmail,
          service_title: fullBooking.serviceName,
          booking_date: fullBooking.date,
          booking_time: fullBooking.timeSlot,
          notes: fullBooking.notes || '',
          attachments: fullBooking.attachments || [],
          base_price: fullBooking.basePrice,
          currency: fullBooking.currency || 'NGN',
          price_pi: fullBooking.pricePi,
          payment_status: fullBooking.paymentStatus,
          created_at: fullBooking.createdAt,
        };

        // If ID matches UUID format, pass it explicitly, otherwise omit so Supabase generates UUID
        const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(fullBooking.id);
        if (isUuid) {
          payload.id = fullBooking.id;
        }

        const { data, error } = await safeSupabaseInsert('bookings', payload);

        if (error) {
          console.warn('[Supabase Note] Failed to insert booking in database:', error.message);
          if (error.code === '42501') logRLSHint('bookings');
        } else if (data && data[0]) {
          console.log('[Supabase Success] Booking saved to database:', data[0]);
          if (data[0].id) {
            fullBooking.id = data[0].id;
          }
        }
      } catch (e: any) {
        console.error('[Supabase Exception] Booking insertion failed:', e?.message || e);
      }
    }

    const currentBookings = this.getBookingsLocal();
    const updatedBookings = [fullBooking, ...currentBookings.filter(b => b.id !== fullBooking.id)];
    localStorage.setItem(LOCAL_BOOKINGS_KEY, JSON.stringify(updatedBookings));

    return fullBooking;
  },

  async updateBookingStatusAsync(bookingId: string, status: BookingStatus): Promise<Booking[]> {
    if (isSupabaseConfigured()) {
      console.log(`[Supabase Request] Updating booking status id="${bookingId}" to "${status}"...`);
      try {
        const { data, error } = await safeSupabaseUpdate('bookings', { status, updated_at: new Date().toISOString() }, 'id', bookingId);

        if (error) {
          console.warn('[Supabase Note] Failed to update booking status in database:', error.message);
          if (error.code === '42501') logRLSHint('bookings');
        } else if (!data || data.length === 0) {
          console.warn(`[Supabase Warning] 0 rows updated for booking id="${bookingId}".`);
        } else {
          console.log('[Supabase Success] Booking status updated in database:', data[0]);
        }
      } catch (e: any) {
        console.error('[Supabase Exception] Booking status update failed:', e?.message || e);
      }

      return await this.getBookingsAsync();
    }

    const currentBookings = this.getBookingsLocal();
    const updatedBookings = currentBookings.map((b) => {
      if (b.id === bookingId) {
        return { ...b, status, updatedAt: new Date().toISOString() };
      }
      return b;
    });

    localStorage.setItem(LOCAL_BOOKINGS_KEY, JSON.stringify(updatedBookings));
    return updatedBookings;
  },

  async submitBookingReviewAsync(bookingId: string, rating: number, comment: string): Promise<Booking[]> {
    const reviewDate = new Date().toISOString();

    if (isSupabaseConfigured()) {
      console.log(`[Supabase Request] Saving review for booking id="${bookingId}"...`);
      try {
        const { data, error } = await safeSupabaseUpdate('bookings', {
          rating,
          review_comment: comment,
          review_date: reviewDate,
          updated_at: reviewDate,
        }, 'id', bookingId);

        if (error) {
          console.warn('[Supabase Note] Failed to save booking review in database:', error.message);
          if (error.code === '42501') logRLSHint('bookings');
        } else {
          console.log('[Supabase Success] Booking review saved in database:', data);
        }
      } catch (e: any) {
        console.error('[Supabase Exception] Booking review submission failed:', e?.message || e);
      }

      return await this.getBookingsAsync();
    }

    const currentBookings = this.getBookingsLocal();
    const updatedBookings = currentBookings.map((b) => {
      if (b.id === bookingId) {
        return {
          ...b,
          rating,
          reviewComment: comment,
          reviewDate,
          updatedAt: reviewDate,
        };
      }
      return b;
    });

    localStorage.setItem(LOCAL_BOOKINGS_KEY, JSON.stringify(updatedBookings));
    return updatedBookings;
  }
};
