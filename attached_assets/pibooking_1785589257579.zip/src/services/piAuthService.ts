import { PiUser } from '../types';

let isPiInitialized = false;

const PI_SANDBOX = import.meta.env.VITE_PI_SANDBOX === 'true';

export const piAuthService = {
  initSDK(): boolean {
    if (typeof window === 'undefined' || !window.Pi) {
      return false;
    }

    if (!isPiInitialized) {
      try {
        window.Pi.init({ version: '2.0', sandbox: PI_SANDBOX });
        isPiInitialized = true;
      } catch (e) {
        console.warn('Pi SDK init warning:', e);
      }
    }

    return true;
  },

  async authenticateUser(): Promise<PiUser> {
    if (typeof window === 'undefined' || !window.Pi) {
      throw new Error('Pi SDK not detected. Please open this app inside the Pi Browser to authenticate.');
    }

    this.initSDK();

    const auth = await window.Pi.authenticate(['username', 'payments'], (incompletePayment) => {
      console.warn('Incomplete Pi payment detected:', incompletePayment);
    });

    if (!auth || !auth.user) {
      throw new Error('Pi authentication failed: no user returned.');
    }

    return {
      username: auth.user.username,
      uid: auth.user.uid,
      accessToken: auth.accessToken,
      verified: true,
    };
  }
};
