import { PiPaymentResult } from '../types';
import { piAuthService } from './piAuthService';

export const piPaymentService = {
  async executePayment(params: {
    amountPi: number;
    memo: string;
    metadata: Record<string, any>;
  }): Promise<PiPaymentResult> {
    if (typeof window === 'undefined' || !window.Pi) {
      throw new Error('Pi SDK not detected. Payments require the Pi Browser.');
    }

    piAuthService.initSDK();

    return new Promise<PiPaymentResult>((resolve, reject) => {
      try {
        window.Pi!.createPayment(
          {
            amount: params.amountPi,
            memo: params.memo,
            metadata: params.metadata,
          },
          {
            onReadyForServerApproval: (paymentId: string) => {
              console.log('Pi Payment ready for server approval:', paymentId);
            },
            onReadyForServerCompletion: (paymentId: string, txid: string) => {
              console.log('Pi Payment completed with txid:', txid);
              resolve({
                identifier: paymentId,
                txHash: txid,
                amount: params.amountPi,
                memo: params.memo,
              });
            },
            onCancel: (paymentId: string) => {
              reject(new Error(`Payment ${paymentId} cancelled by user.`));
            },
            onError: (error: Error) => {
              reject(error);
            },
          }
        );
      } catch (err) {
        reject(err);
      }
    });
  }
};
