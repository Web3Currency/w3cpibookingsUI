-- ====================================================================
-- W3C PI BUSINESS OPERATING SYSTEM (PI BUSINESS OS)
-- SUPABASE PRODUCTION DATABASE SCHEMA & POLICIES
-- ====================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. CREATE TABLE: Global Settings & Pricing Engine
CREATE TABLE IF NOT EXISTS public.settings (
    id TEXT PRIMARY KEY DEFAULT 'global_settings',
    exchange_rate_ngn NUMERIC(12, 2) NOT NULL DEFAULT 3500.00,
    default_currency TEXT NOT NULL DEFAULT 'NGN',
    timezone TEXT DEFAULT 'Africa/Lagos',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. CREATE TABLE: Business Profile & Availability Operating System
CREATE TABLE IF NOT EXISTS public.business_profile (
    id TEXT PRIMARY KEY DEFAULT 'w3c_digital',
    name TEXT NOT NULL DEFAULT 'W3C Digital Network',
    tagline TEXT DEFAULT 'High-Converting UI/UX & Web Development',
    category TEXT DEFAULT 'web_dev',
    avatar_url TEXT DEFAULT 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Untitled%20%284%29-ie2R59jxk6ypBF6z9h8b2PGAo71RHQ.png',
    pi_wallet_address TEXT DEFAULT 'GBX9...APEX88PI',
    verified_pi_merchant BOOLEAN DEFAULT TRUE,
    rating NUMERIC(3, 2) DEFAULT 4.90,
    reviews_count INT DEFAULT 128,
    location TEXT DEFAULT 'Remote / Worldwide (Zoom / Google Meet)',
    bio TEXT DEFAULT 'Senior Product Design studio crafting sleek mobile apps, Pi Mini Apps, and high-conversion landing pages with full Pi Network payment integration.',
    website TEXT DEFAULT 'https://web3currency.online',
    phone TEXT DEFAULT '+234 814 962 5496',
    email TEXT DEFAULT 'web3currency.info@gmail.com',
    socials JSONB DEFAULT '[
        {"platform": "Twitter / X", "url": "https://x.com/Web3CurrencyNG", "handle": "@Web3CurrencyNG"},
        {"platform": "Telegram", "url": "https://t.me/Web3CurrencyNG", "handle": "@Web3CurrencyNG"},
        {"platform": "Pi Chat", "url": "https://profiles.pinet.com/profiles/adeyemojibola8", "handle": "@adeyemojibola8"}
    ]'::jsonb,
    business_hours JSONB DEFAULT '{
        "monday": {"open": "09:00", "close": "17:00", "active": true},
        "tuesday": {"open": "09:00", "close": "17:00", "active": true},
        "wednesday": {"open": "09:00", "close": "17:00", "active": true},
        "thursday": {"open": "09:00", "close": "17:00", "active": true},
        "friday": {"open": "09:00", "close": "17:00", "active": true},
        "saturday": {"open": "10:00", "close": "15:00", "active": true},
        "sunday": {"open": "00:00", "close": "00:00", "active": false}
    }'::jsonb,
    blocked_dates JSONB DEFAULT '[]'::jsonb,
    gallery_images JSONB DEFAULT '[
        {"id": "g1", "title": "Pi Network DEX Dashboard", "category": "Web App", "imageUrl": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80"},
        {"id": "g2", "title": "Mobile Wallet Interface", "category": "UI/UX Design", "imageUrl": "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&auto=format&fit=crop&q=80"},
        {"id": "g3", "title": "SaaS Analytics Platform", "category": "Dashboard", "imageUrl": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80"}
    ]'::jsonb,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. CREATE TABLE: Services Catalog (Future-Proofed Multi-Currency Pricing)
CREATE TABLE IF NOT EXISTS public.services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    short_description TEXT NOT NULL,
    full_description TEXT,
    cover_image TEXT,
    deliverables TEXT[] DEFAULT '{}',
    duration INT NOT NULL DEFAULT 60,
    base_price NUMERIC(12, 2) NOT NULL DEFAULT 100000.00,
    currency TEXT NOT NULL DEFAULT 'NGN',
    pi_price NUMERIC(10, 2) NOT NULL DEFAULT 28.57,
    status TEXT NOT NULL CHECK (status IN ('Draft', 'Published', 'Archived')) DEFAULT 'Published',
    category TEXT DEFAULT 'web_dev',
    provider_name TEXT DEFAULT 'Alex Rivera',
    provider_role TEXT DEFAULT 'Lead Developer',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. CREATE TABLE: Bookings & Orders Engine
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    status TEXT NOT NULL CHECK (status IN ('Pending', 'Confirmed', 'In Progress', 'Completed', 'Cancelled')) DEFAULT 'Confirmed',
    customer_name TEXT NOT NULL,
    customer_pi_username TEXT NOT NULL,
    customer_phone TEXT,
    customer_email TEXT,
    service_id UUID REFERENCES public.services(id) ON DELETE SET NULL,
    service_title TEXT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TEXT NOT NULL,
    notes TEXT,
    attachments JSONB DEFAULT '[]'::jsonb,
    base_price NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    currency TEXT NOT NULL DEFAULT 'NGN',
    price_pi NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    payment_status TEXT NOT NULL CHECK (payment_status IN ('Paid', 'Unpaid', 'Refunded')) DEFAULT 'Paid',
    rating INT,
    review_comment TEXT,
    review_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. CREATE TABLE: Customer CRM Directory
CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    pi_username TEXT UNIQUE NOT NULL,
    phone TEXT,
    email TEXT,
    total_bookings INT DEFAULT 1,
    total_spend_base NUMERIC(12, 2) DEFAULT 0.00,
    total_spend_pi NUMERIC(10, 2) DEFAULT 0.00,
    currency TEXT DEFAULT 'NGN',
    last_active_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ====================================================================
-- SUPABASE STORAGE BUCKETS (FOR PRODUCTION MEDIA ASSETS)
-- ====================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES 
    ('service-images', 'service-images', true),
    ('business-logo', 'business-logo', true),
    ('gallery', 'gallery', true),
    ('receipts', 'receipts', true)
ON CONFLICT (id) DO NOTHING;

-- Public Storage Read Policies
CREATE POLICY "Public Read Service Images" ON storage.objects FOR SELECT USING (bucket_id = 'service-images');
CREATE POLICY "Public Read Business Logo" ON storage.objects FOR SELECT USING (bucket_id = 'business-logo');
CREATE POLICY "Public Read Gallery" ON storage.objects FOR SELECT USING (bucket_id = 'gallery');
CREATE POLICY "Public Read Receipts" ON storage.objects FOR SELECT USING (bucket_id = 'receipts');

-- Authenticated Storage Write Policies
CREATE POLICY "Admin Upload Service Images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'service-images' AND auth.role() = 'authenticated');
CREATE POLICY "Admin Upload Business Logo" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'business-logo' AND auth.role() = 'authenticated');

-- ====================================================================
-- AUTOMATIC TIME STAMP & RE-CALCULATION TRIGGERS
-- ====================================================================

-- Function: Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_timestamp_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_settings_updated_at ON public.settings;
CREATE TRIGGER set_settings_updated_at BEFORE UPDATE ON public.settings FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();

DROP TRIGGER IF EXISTS set_business_profile_updated_at ON public.business_profile;
CREATE TRIGGER set_business_profile_updated_at BEFORE UPDATE ON public.business_profile FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();

DROP TRIGGER IF EXISTS set_services_updated_at ON public.services;
CREATE TRIGGER set_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();

DROP TRIGGER IF EXISTS set_bookings_updated_at ON public.bookings;
CREATE TRIGGER set_bookings_updated_at BEFORE UPDATE ON public.bookings FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();

-- Function: Auto-recalculate service Pi price whenever base price OR exchange rate changes
CREATE OR REPLACE FUNCTION recalculate_service_pi_price()
RETURNS TRIGGER AS $$
DECLARE
    current_rate NUMERIC(12, 2);
BEGIN
    SELECT exchange_rate_ngn INTO current_rate FROM public.settings WHERE id = 'global_settings' LIMIT 1;
    IF current_rate IS NULL OR current_rate <= 0 THEN
        current_rate := 3500.00;
    END IF;

    NEW.pi_price := ROUND((NEW.base_price / current_rate), 2);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS auto_calc_service_pi_price ON public.services;
CREATE TRIGGER auto_calc_service_pi_price
BEFORE INSERT OR UPDATE OF base_price ON public.services
FOR EACH ROW EXECUTE FUNCTION recalculate_service_pi_price();

-- Function: Recalculate all services when global exchange rate is updated
CREATE OR REPLACE FUNCTION sync_all_services_on_exchange_rate_change()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE public.services
    SET pi_price = ROUND((base_price / NEW.exchange_rate_ngn), 2);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS sync_services_rate ON public.settings;
CREATE TRIGGER sync_services_rate
AFTER UPDATE OF exchange_rate_ngn ON public.settings
FOR EACH ROW EXECUTE FUNCTION sync_all_services_on_exchange_rate_change();

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================

ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

-- Public Read & Customer Booking Access
CREATE POLICY "Public read settings" ON public.settings FOR SELECT USING (true);
CREATE POLICY "Public read business profile" ON public.business_profile FOR SELECT USING (true);
CREATE POLICY "Public read published services" ON public.services FOR SELECT USING (status = 'Published' OR auth.role() = 'authenticated');
CREATE POLICY "Public create booking" ON public.bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Public view bookings" ON public.bookings FOR SELECT USING (true);

-- Authenticated Business Console Management Access
CREATE POLICY "Admin write settings" ON public.settings FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin write business profile" ON public.business_profile FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin full manage services" ON public.services FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin full manage bookings" ON public.bookings FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin full manage customers" ON public.customers FOR ALL USING (auth.role() = 'authenticated');

-- ====================================================================
-- SEED DATA
-- ====================================================================

INSERT INTO public.settings (id, exchange_rate_ngn, default_currency, timezone)
VALUES ('global_settings', 3500.00, 'NGN', 'Africa/Lagos')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.business_profile (id, name, tagline, category, phone, email, website)
VALUES ('w3c_digital', 'W3C Digital Network', 'High-Converting UI/UX & Web Development', 'web_dev', '+234 814 962 5496', 'web3currency.info@gmail.com', 'https://web3currency.online')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.services (id, title, short_description, full_description, cover_image, deliverables, duration, base_price, currency, pi_price, status, category, provider_name, provider_role)
VALUES
(
    'a1111111-1111-1111-1111-111111111111',
    '1-Page SaaS / Landing Page',
    'Custom React & Tailwind single-page website built for high conversions and mobile responsiveness.',
    'Sleek landing page crafted with modern animation, clear call-to-actions, and high performance.',
    'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
    ARRAY['Custom UI design & modern layout', 'Mobile & tablet optimization', 'SEO-friendly setup & metadata', 'Instant domain deployment assistance'],
    90,
    157500.00,
    'NGN',
    45.00,
    'Published',
    'landing_page',
    'Alex Rivera',
    'Full-Stack Developer'
),
(
    'b2222222-2222-2222-2222-222222222222',
    'Full-Stack Web App Build',
    'Complete multi-page web application with interactive features, dashboard layouts, and database setup.',
    'Full-stack architecture featuring state management, API routes, authentication, and database integration.',
    'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80',
    ARRAY['Custom frontend component architecture', 'Backend API integration & database setup', 'Responsive mobile-first interface', 'Deployment & production delivery'],
    120,
    262500.00,
    'NGN',
    75.00,
    'Published',
    'web_dev',
    'Alex Rivera',
    'Lead Software Engineer'
),
(
    'c3333333-3333-3333-3333-333333333333',
    'Pi App UI/UX Design Audit',
    'Comprehensive 60-min interactive review of your Pi App UX, navigation flows, and payment triggers.',
    'In-depth design audit pointing out UX bottlenecks, conversion leaks, and mobile usability enhancements.',
    'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=800&auto=format&fit=crop&q=80',
    ARRAY['Live 1-on-1 UI walkthrough', 'Heuristic design feedback PDF', 'Mobile touch-target & contrast audit', 'Conversion optimization checklist'],
    45,
    43750.00,
    'NGN',
    12.50,
    'Published',
    'ux_design',
    'Alex Rivera',
    'Lead Product Designer'
),
(
    'd4444444-4444-4444-4444-444444444444',
    'Pi Payment SDK Setup',
    'Technical integration of Pi Network authentication and payment SDK (pi.js) into your web app.',
    'Seamless integration of Pi Browser JS bridge and server verification callbacks for mainnet/testnet.',
    'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&auto=format&fit=crop&q=80',
    ARRAY['Pi Browser JS bridge configuration', 'Backend transaction verification API', 'Testnet & Mainnet sandbox setup', '30 days post-integration support'],
    60,
    105000.00,
    'NGN',
    30.00,
    'Published',
    'pi_sdk',
    'Alex Rivera',
    'Web3 Lead Engineer'
)
ON CONFLICT (id) DO NOTHING;
